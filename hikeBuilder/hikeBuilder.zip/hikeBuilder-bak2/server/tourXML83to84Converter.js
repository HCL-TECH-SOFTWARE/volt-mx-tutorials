var fs = require('fs-extra')
	, path = require('path')
	, convert = require('xml-js');

function runConversions(inputPath, config) {
	if (!fs.existsSync(inputPath)) {
		console.log("Invalid directory provided! Given directory path does not contain 'guidedtours' folder.");
		return;
	}

	try {
		config = config || {};
		var isTourSP4 = config.isTourSP4 ? config.isTourSP4 : false;
		var options = {
			compact: false,
			spaces: 4
		};

		console.log("\nConverting Hikes ..");
		//Iterate through each hike
		var hikesDirPath = path.resolve(inputPath, 'hikes');
		fs.readdirSync(hikesDirPath)
			.forEach(function (hike) {
				var hikePath = path.resolve(hikesDirPath, hike, hike + '.xml');
				var hikeXML = fs.readFileSync(hikePath);

				var parsedXML = parseXML(hikeXML);
				var convertedObj = validateAndConvertXMLs(parsedXML, 'Hike', isTourSP4);


				if (convertedObj && convertedObj.xml) {
					var newHikePath = hikePath;
					if (convertedObj.id !== hike) {
						newHikePath = path.resolve(hikesDirPath, convertedObj.id, convertedObj.id + '.xml');
						fs.removeSync(path.resolve(hikesDirPath, hike));
						fs.mkdirSync(path.resolve(hikesDirPath, convertedObj.id));
						console.log('\t Converting Hike ' + hike + ' to ' + convertedObj.id);
					}
					fs.writeFileSync(newHikePath, convert.json2xml(convertedObj.xml, options));
					console.log('\t' + hike + '.xml' + " .. DONE");
				} else {
					console.log('\t' + hike + ".. Not Converted");
				}
			});

		console.log("\nConverting Tours ..");
		//Iterate through each tours
		var toursDirPath = isTourSP4 ? inputPath : path.resolve(inputPath, 'tours');
		fs.readdirSync(toursDirPath)
			.forEach(function (tour) {
				var tourPath = isTourSP4 ? path.resolve(toursDirPath, tour) : path.resolve(toursDirPath, tour, tour + '.xml');

				if (tourPath.endsWith(".xml")) {
					var tourXML = fs.readFileSync(tourPath);

					var parsedXML = parseXML(tourXML);
					var convertedObj = validateAndConvertXMLs(parsedXML, 'GuidedTour', isTourSP4);
					if (convertedObj && convertedObj.xml) {
						var newTourPath = tourPath;
						if (convertedObj.id !== tour) {
							config.tourFileName = convertedObj.id;
							if (isTourSP4) {
								newTourPath = path.resolve(toursDirPath, convertedObj.id + '.xml');
								fs.removeSync(tourPath);
							} else {
								newTourPath = path.resolve(toursDirPath, convertedObj.id, convertedObj.id + '.xml');
								fs.removeSync(path.resolve(toursDirPath, tour));
								fs.mkdirSync(path.resolve(toursDirPath, convertedObj.id));
							}
							console.log('\t Converting Tour ' + tour + ' to ' + convertedObj.id);
						}
						fs.writeFileSync(newTourPath, convert.json2xml(convertedObj.xml, options));
						console.log('\t' + tour + '.xml' + " .. DONE");
					} else {
						console.log('\t' + tour + ".. Not Converted");
					}
				}
			});

	} catch (Error) {
		console.log(Error);
	}
}

/**

 * 

 * @param {string} xmlString83 - tour/hike xml of 8.3 version
 * @returns {string} - tour/hike xml of 8.4 version
 */
/**
 *  * Validates and Converts a given tour/hike xml by following the below steps:
 *  1.  Validate Mandatory Fields for Hikes and Tours
 *	  -   Add title by default if not exists
 *	  -   Add description by default if not Exists
 *	  -   Validate KUID by length 32.
 *	  -   Validate ID by title and of length 36.
 *  2.  Move the storedconditions (if present) into Guided Tour
 *  3.  Make all tag names start with Uppercase <-- like this
 * 
 * @function validateAndConvertXMLs
 * @param  {any} parsedXML XML Object to be validated
 * @param  {any} xmlType Tour/Hike
 * @param  {any} isTourSP4 is the tour Created in isTourSP4
 * @return {Object} - {id: modified ID, xml :Valid tour/hike xml}
 */
function validateAndConvertXMLs(parsedXML, xmlType, isTourSP4) {
	try {
		//Step 1.
		validateTitle(parsedXML, xmlType);
		validateDescription(parsedXML, xmlType);
		validateKUID(parsedXML, xmlType);
		var newID = validateID(parsedXML, xmlType);

		//Step 2.
		if (!isTourSP4 && isPresentStoredConditions(parsedXML)) {
			moveStoredConditions(parsedXML, xmlType);
		}

		//Step3.
		forEachElement(parsedXML, function (child) {
			child.name = startWithUppercase(child.name);
		});

		return {
			xml: parsedXML,
			id: newID
		};
	} catch (Error) {
		console.log(Error);
	}
	return null;
}

function parseXML(xmlString) {
	try {
		var options = {
			compact: false,
			spaces: 4
		};
		var xmlJSON = JSON.parse(convert.xml2json(xmlString, options));

		return xmlJSON;
	} catch (Error) {
		console.log(Error);
	}
}

function validateTitle(parsedXML, xmlType) {
	var xmlElement = getElementsByTagName(parsedXML, xmlType)[0];
	if (!xmlElement.attributes['title']) {
		xmlElement.attributes['title'] = xmlElement.attributes['id'];
	}
}

function validateKUID(parsedXML, xmlType) {
	var xmlElement = getElementsByTagName(parsedXML, xmlType)[0];
	var kuid = getKUID();
	if (xmlElement.attributes['kuid']) {
		kuid = xmlElement.attributes['kuid'];
	}

	kuid = kuid.length >= 32 ? kuid.substring(0, 32) : getKUID();
	xmlElement.attributes['kuid'] = kuid;
}

function validateID(parsedXML, xmlType) {
	var xmlElement = getElementsByTagName(parsedXML, xmlType)[0];
	var title = xmlElement.attributes['title'];
	var id = title.split(" ").join('').substring(0, 36);
	xmlElement.attributes['id'] = id;
	return id;
}

function validateDescription(parsedXML, xmlType) {
	var xmlElement = getElementsByTagName(parsedXML, xmlType)[0];

	//If Description is not present
	if (getElementsByTagName(xmlElement, 'Description').length <= 0) {
		var description = xmlElement.attributes['id'];

		//Add at the beginning of the array
		xmlElement.elements.unshift({
			name: "Description",
			type: "element",
			elements: [{
				type: "text",
				text: description
			}]
		});
	}
}

function isPresentStoredConditions(parsedXML) {
	return getElementsByTagName(parsedXML, 'storedconditions').length > 0;
}

function moveStoredConditions(parsedXML, xmlType) {
	var storedconditions = getElementsByTagName(parsedXML, 'storedconditions')[0];
	var tour = getElementsByTagName(parsedXML, xmlType)[0];

	tour.elements.push(storedconditions);

	parsedXML.elements = parsedXML.elements.filter(function (child) {
		return child.name !== "storedconditions";
	});
}

function startWithUppercase(string) {
	return string[0].toUpperCase() + string.slice(1).toLowerCase();
}

/**
	Description: Recursively process children
*/
function forEachElement(parent, cb) {
	(parent.elements || [])
		.filter(function (child) {
			return child.type === 'element';
		})
		.forEach(function (child) {
			cb(child);
			forEachElement(child, cb);
		});
}

/**
	Description: Returns only XML elements with tagName under a XML Node
	@param parent: Parent node under which elements has to be retured
	@param tagName: Tag name to filter
*/
function getElementsByTagName(parent, tagName) {
	return (parent.elements || [])
		.filter(function (child) {
			//Text node won't have name. Only type = 'elements' node will have name
			return child.type === 'element'
				&& child.name.toLowerCase() === tagName.toLowerCase();
		});
}

function getKUID() {
	return 'xxxxxxtx-xxax-4xrx-yxux-xxxxxxnx'.replace(/[xy]/g, function (c) {
		var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

exports.convertTours = runConversions;