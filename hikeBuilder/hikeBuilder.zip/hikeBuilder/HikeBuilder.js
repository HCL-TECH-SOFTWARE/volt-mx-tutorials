
/*****SCRIPT GUARD(BEGIN)*****/
if (window.__konyviz_loaded_scripts__['addon/hikeBuilder/hikeBuilder.js']) {
	throw new Error('The script [addon/hikeBuilder/hikeBuilder.js] is already loaded.');
} else {
	window.__konyviz_loaded_scripts__['addon/hikeBuilder/hikeBuilder.js'] = 1;
}
/*****SCRIPT GUARD(END)*****/

/*global define:true*/
define([
	'utils/kvlogger'
	, 'addon/hikeBuilder/client/hikeBuilderRenderer'
	, 'addon/hikeBuilder/client/hikeBuilderController'
]
	, function (
		logr
		, hikeBuilderRenderer
		, hikeBuilderController
	) {

		var moduleName = 'HikeBuilder';
		logr.trace('Loading..' + moduleName);

		var extnService = null;
		return {
			initialize: function (es) {
				extnService = es;
				logr.trace('Called initialize..' + moduleName);
			},

			registerEvents: function () {
				logr.trace('Called registerEvents..' + moduleName);

			},

			subscribeEvents: function () {
				logr.trace('Called subscribeEvents..' + moduleName);
			},

			eventHandler: function (src, eventType) {
				logr.trace('Called eventHandler..' + moduleName);
			},

			render: function () {
				logr.trace('Called render..' + moduleName);
				hikeBuilderRenderer.render(extnService);
			},

			postRender: function () {
				logr.trace('Called postRender..' + moduleName);
			},

			unregisterEvents: function () {
				logr.trace('Called unregisterEvents..' + moduleName);
			},

			unsubscribeEvents: function () {
				logr.trace('Called unsubscribeEvents..' + moduleName);
			},
		};
	});
