var express = require('express')
	, multer = require('multer')
	, bodyParser = require('body-parser')
	, http = require('http')
	, path = require('path')
	, builderSettings = require('./server/builderSettings')
	, serverUtils = require('./server/builderServerUtils')
	, app = null
	, HikeBuilderServer = null;

var storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, builderSettings.UPLOADS_PATH);
	},
	filename: function (req, file, cb) {
		cb(null, file.originalname);
	}
});

var upload = multer({ storage: storage });
function startServer() {

	app = express();
	app.use(bodyParser.json()); // support json encoded bodies
	app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
	app.use(require('cookie-parser')());
	app.use(require('body-parser').urlencoded({ extended: true }));
	app.use(require('express-session')({ secret: 'keyboard cat', resave: true, saveUninitialized: true }));
	app.use(function (req, res, next) {
		res.header("Access-Control-Allow-Origin", "*");
		res.header("Access-Control-Allow-Methods", "GET,POST");
		res.header("Access-Control-Allow-Headers", "Origin, Authorization, content-type, x-csrf-token, x-kony-authorization");
		next();
	});

	app.set('port', 1594);

	HikeBuilderServer = http.createServer(app);

	HikeBuilderServer.listen(app.get('port'), function () {
		console.log('Volt MX Hike Builder Sever listening on port %d', app.get('port'));
	});


	HikeBuilderServer.on('listening', function () {
		console.log('Volt MX Hike Builder Server is up!!');
		console.log('Open http://127.0.0.1:' + app.get('port') + '/ in chrome.');
	});

	app.use(express.static(path.join(__dirname, 'client')));

	app.post('/service/hikes/upload', upload.single('tourZip'), function (req, res) {
		serverUtils.evaluateZip(req.file, function (data) {
			res.send(JSON.stringify(data));
		});
	});

	app.post('/service/hikes', function (req, res) {
		if (req.body) {
			if (req.body.data && req.body.data.func) {
				serverUtils.execFunction(req.body.data, function (response) {
					if (response) {
						res.send(response);
					} else {
						res.sendStatus(401);
					}
				});
			} else {
				res.sendStatus(401);
			}
		} else {
			res.sendStatus(401);
		}
	});

	app.get('/css/guidedtour.css', function (req, res) {
		res.sendFile(path.join(__dirname, '..', 'hikeengine', 'client', 'guidedtour.css'));
	});

	app.get('/*', function (req, res) {
		res.sendFile(path.join(__dirname, 'client', 'pages', 'index.html'));
	});

	return app;
}


module.exports.start = function () {
	console.log("Starting Volt MX Hike Builder");
	startServer();
};

module.exports.stop = function () {
	console.log("Stoping Volt MX Hike Builder");
};