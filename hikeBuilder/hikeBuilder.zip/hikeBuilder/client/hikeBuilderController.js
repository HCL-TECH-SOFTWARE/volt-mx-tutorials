/*****SCRIPT GUARD(BEGIN)*****/
if (window.__konyviz_loaded_scripts__['addon/hikeBuilder/client/hikeBuilderController.js']) {
	throw new Error('The script [addon/hikeBuilder/client/hikeBuilderController.js] is already loaded.');
} else {
	window.__konyviz_loaded_scripts__['addon/hikeBuilder/client/hikeBuilderController.js'] = 1;
}
/*****SCRIPT GUARD(END)*****/

/*global define:true*/
define([
	'utils/kvlogger'
	, 'core/postMessageManager'
	, 'modules/popups/popupTemplates'
	, 'modules/popups/popupUtils'
	, 'addon/hikeengine/client/guidedTour/tour'
	, 'sdk/domSelector'
]
	, function (
		logr
		, pmm
		, popupTemplates
		, popupUtils
		, Tour
		, domSelector
	) {

		var ns = {}
			, hikeBuilderPopup
			, popWindow
			, botOrigin = 'http://localhost:1594'
			, botLocale = 'en-us' // TODO: Get user locale from preference?
			, botFullURL = `${botOrigin}?locale=${botLocale}`;


		var HIKEBUILDER_WINDOW_WIDTH = 400;

		function assertHikeBuilderURL(successCb, failCB) {
			var url = botFullURL;

			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function () {
				if (xhttp.readyState === 4 && xhttp.status === 200) {
					successCb(url);
				} else if (xhttp.readyState === 4 && xhttp.status === 0) {
					failCB();
				}
			};
			xhttp.open("GET", url, true);
			xhttp.send();
		}

		function getFrameNode() {
			if (popWindow) {
				return {
					contentWindow: popWindow
				};
			}
			var bNode = hikeBuilderPopup ? $KU.getNodeByModel(hikeBuilderPopup.browserWgt) : null;
			return bNode ? bNode.getElementsByTagName('iframe')[0] : null;
		}

		function postMessageToHikeBuilder(msg) {
			var iframeNode = getFrameNode();
			iframeNode ? iframeNode.contentWindow.postMessage(msg, botOrigin) : null;
		}

		function receiveMessage(event) {

			if (event.origin !== botOrigin) { return; }

			var cmd = event.data.command;
			if (!cmd) { return; }

			switch (event.data.command) {
				case 'userDetails':
					postMessageToHikeBuilder({
						messageType: 'userDetails',
						userDetails: {
							username: _kgb_.modules.utils.getCurrentUserName()
						}
					});
					break;
				case 'close_hikeBuilder':
					hikeBuilderPopup && hikeBuilderPopup.dismiss();
					hikeBuilderPopup = null;
					break;
				case 'initiateDomSelection':
					$KU.getNodeByModel(hikeBuilderPopup).parentNode.style.display = "none";
					domSelector.initiateDOMSelection(function (vizElement) {
						delete vizElement.nodeToBeHighlighted;
						postMessageToHikeBuilder({
							messageType: 'vizElement',
							text: JSON.stringify(vizElement),
							sender: event.data.sender,
							recipient: event.data.recipient
						});
						$KU.getNodeByModel(hikeBuilderPopup).parentNode.style.display = null;
						domSelector.endDOMSelection();
					});
					break;
				case 'runTourPreview':
					runTourPreview(event.data.tour);
					break;
			}
		}

		function runTourPreview(tourJSON) {
			var tour = tourJSON;
			var tourContext = visualizer.IQ.getCurrentContext({});
			$KU.getNodeByModel(hikeBuilderPopup).parentNode.style.display = "none";
			tour.onAbort = function () {
				postMessageToHikeBuilder({
					messageType: 'Text',
					text: "tour Aborted"
				});
				$KU.getNodeByModel(hikeBuilderPopup).parentNode.style.display = null;
			};
			tour.onComplete = function () {
				postMessageToHikeBuilder({
					messageType: 'Text',
					text: "tour Compleated"
				});
				$KU.getNodeByModel(hikeBuilderPopup).parentNode.style.display = null;
			};
			var tourInstance = new Tour(tour, tourContext);
			tourInstance.play();

		}

		function addCommunicationAPI() {
			pmm.removeHandler(botOrigin);
			pmm.setHandler(botOrigin, receiveMessage);
		}

		function focusHikeBuilder() {
			if (hikeBuilderPopup) {
				return true;
			}
			if (popWindow) {
				if (_kgb_.modules.config.isNodeWebkitEnv) {
					popWindow._win_.focus();
				} else {
					if (popWindow.closed) {
						popWindow = null;
						return false;
					}
					popWindow.focus();
				}
				return true;
			}
			return false;
		}

		ns.openHikeBuilder = function () {

			if (focusHikeBuilder()) { return; }

			//Check URL is UP
			assertHikeBuilderURL(function () {

				hikeBuilderPopup = popupTemplates.createPopupWithRichText({
					title: "Volt MX Hike Builder",
					id: 'urlBrowserPopup',
					doNotShowHeader: false,
					resizable: false,
					draggable: true,
					containerWeight: (HIKEBUILDER_WINDOW_WIDTH / document.body.offsetWidth) * 100
				});

				hikeBuilderPopup.skin = hikeBuilderPopup.skin + " hikeBuilderPopup";
				hikeBuilderPopup.ismodal = false;

				hikeBuilderPopup.init = (popupModel) => {

					hikeBuilderPopup.browserWgt = popupModel.widgets()[0];
					let BODY_HTML = "<div class='url_browser_body'><iframe class='url_browser_frame' src='"
						+ botFullURL + "' style='width:100%; height: 100%; border:0px;'></iframe></div>";

					hikeBuilderPopup.browserWgt.text = BODY_HTML;
				};

				hikeBuilderPopup.onRender = function () {
					$KW.Utils.initializeNewWidgets([hikeBuilderPopup.browserWgt], null, false, function () {
						addCommunicationAPI();
						setTimeout(function () {
							var rootPopupNode = $KU.getNodeByModel(hikeBuilderPopup).parentNode;
							rootPopupNode.style.left = null;
							rootPopupNode.style.top = null;
							rootPopupNode.style.right = '2%';
							rootPopupNode.style.bottom = '5%';
							rootPopupNode.style.height = '90%';
						}, 16);
					}, true);
				};

				hikeBuilderPopup.postDismissHandler = function (model) {
					popupUtils.postDismissHandler(model);
					hikeBuilderPopup = null;
				};
				hikeBuilderPopup.show();

			}, function () {
				hikeBuilderPopup = null;
				popWindow = null;
				logr.error("Error: Can't open hike window.");
				_kgb_.modules.pxStorage.pxe.popupUIs.alert("Error: Can't open hike window.");
			});
		};

		ns.openPopoutHikeBuilder = function () {
			if (focusHikeBuilder()) { return; }

			//Check URL is UP
			assertHikeBuilderURL(function () {

				addCommunicationAPI();

			}, function () {
				hikeBuilderPopup = null;
				popWindow = null;
				logr.error("Error: Can't open hike window.");
				_kgb_.modules.pxStorage.pxe.popupUIs.alert("Error: Can't open hike window.");
			});
		};

		return ns;
	});