/*****SCRIPT GUARD(BEGIN)*****/
if (window.__konyviz_loaded_scripts__['addon/hikeBuilder/client/hikeBuilderRenderer.js']) {
	throw new Error('The script [addon/hikeBuilder/client/hikeBuilderRenderer.js] is already loaded.');
} else {
	window.__konyviz_loaded_scripts__['addon/hikeBuilder/client/hikeBuilderRenderer.js'] = 1;
}
/*****SCRIPT GUARD(END)*****/

/*global define:true*/
define([
	'addon/hikeBuilder/client/hikeBuilderController'
]
	, function (
		hikeBuilderController
	) {

		var ns = {};

		ns.config = {};
		ns.render = function (extnService) {
			visualizer.utils.addShortcut({
				id: "hikebuilder-root",
				skin: "hikebuilder-root",
				icon: "/addon/hikeBuilder/client/assets/png/hikeBuilder-ico.png",
				tooltip: "Hike Builder",
				isVisible: true,
				isEnabled: function () {
					return !visualizer.utils.isFrameInView();
				},
				onClickHandler: hikeBuilderController.openHikeBuilder
			}).then(function () {
				visualizer.view.addLinkedStyleSheet('/addon/hikeBuilder/client/hikeBuilderStyles.css');
			});
		};
		return ns;
	});
