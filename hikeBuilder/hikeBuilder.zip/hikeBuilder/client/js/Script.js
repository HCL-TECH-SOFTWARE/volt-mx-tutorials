var myApp = angular
	.module('myModule', ['ngAnimate', 'ngRoute'])
	.config(function ($routeProvider) {
		$routeProvider
			.when('/home', {
				templateUrl: 'pages/usages.html'
			})
			.when('/cards', {
				templateUrl: 'pages/cards.html'
			})
			.when('/hikes', {
				templateUrl: 'pages/hikes.html'
			})
			.when('/tours', {
				templateUrl: 'pages/tours.html'
			})
			.otherwise({
				redirectTo: '/home'
			});
	})
	.filter('capitalize', function () {
		return function (input) {
			return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
		};
	})
	.filter('isMetaEditable', function () {
		var editableKeys = ["creator", "createdon"];
		return function (input) {
			return editableKeys.indexOf(input.toLowerCase()) !== -1;
		};
	})
	.filter('getbyid', function () {
		return function (items) {
			if (items) {
				return items.map(item => item.id);
			} else {
				return items;
			}
		};
	})
	.filter('bytext', function () {
		return function (expression) {
			if (typeof (expression) === 'object') {
				return JSON.stringify(expression, null, 4);
			} else {
				return expression;
			}
		};
	})
	.directive('fileModel', ['$parse', function ($parse) {
		function fn_link(scope, element, attrs) {
			var onChange = $parse(attrs.fileModel);
			element.on('change', function (event) {
				onChange(scope, { $files: event.target.files });
			});
		}
		return {
			link: fn_link
		};
	}])
	.controller(
		"myController",
		function ($scope, $http, $sce) {
			$scope.apply = function () {
				setTimeout(() => {
					$scope.$apply();
				}, 100);
			};
			$scope.onMoreClick = function (card) {
				console.log(card.type);
			};

			$scope.isCardPreviewModeEnabled = false;
			$scope.getCardTemplate = function () {
				return $scope.isCardPreviewModeEnabled ? 'templates/cardNewTemplate.htm' : 'templates/cardTemplate.htm';
			};
			$scope.getCardTemplateClass = function () {
				return $scope.isCardPreviewModeEnabled ? 'cardspreview' : '';
			};

			$scope.closeWindow = function () {
				var ModifiedCount = 0;
				var confirmationString = "Closing Window will revert all unsaved changes.<br> Below Items are unsaved.";
				Object.keys($scope.modifiedObjects).map(function (type) {
					var Items = $scope.modifiedObjects[type];
					if (Items && Items.length > 0) {
						ModifiedCount += Items.length;
						confirmationString += "<h3>" + type + "</h3><ul>";
						confirmationString += Items.map(item => "<li>" + item + "</li>").join("");
						confirmationString += "</ul>";
					}
				});
				confirmationString += "<br>Do you still want to Close the Window?";
				if (ModifiedCount > 0) {
					$scope.showConfirmationPopUp({
						title: "Alert Alert !!!!!!!",
						message: confirmationString,
						okText: "cancel",
						cancelText: "Close Window",
						onFailure: function () {
							close();
						}
					});
				} else {
					close();
				}
			};

			$scope.userName = "Anonymous";

			$scope.allItems = {
				tours: {},
				hikes: {},
				cards: {}
			};

			$scope.cardtoHikeMap = {};

			$scope.hiketoTourMap = {};

			$scope.modifiedObjects = {
				cards: [],
				hikes: [],
				tours: []
			};

			$scope.runTourPreview = function (tourID) {
				invoke('/service/hikes', 'getFullTour', { 'id': tourID }, function (err, data) {
					var tourJSON = data;
					runpreviewTour(tourJSON);
				});
			};

			var formData = null;
			$scope.myFiles = function ($files) {
				formData = new FormData();
				formData.append('tourZip', $files[0]);
			};

			$scope.onSubmitTourZip = function () {
				if (formData === null) {
					return;
				}
				$scope.UploadStatusMessage = "Uploading File .....";
				$http
					.post('/service/hikes/upload',
						formData,
						{
							headers: {
								'Content-Type': undefined
							}
						})
					.then(function onSuccess(resp) {
						if (resp.data) {
							onUploadResponse(resp.data);
						}
					}, function onFailure(resp) {
						console.log("resp" + resp);
					});
			};

			function onUploadResponse(data) {
				switch (data.Status) {
					case 'PAUSED':
						$scope.UploadStatusMessage = "Attention Required.....";
						$scope.showConfirmationPopUp({
							title: "Confimation Message !!!!!!!",
							message: data.message + '<br>' + JSON.stringify(data.data, null, 4),
							okText: "Import",
							cancelText: "cancel",
							onSuccess: function () {
								forceImportTourZip(data.filePath, function (data) {
									onUploadResponse(data);
								});
							},
							onFailure: function () {
								$scope.clearFileField();
								$scope.UploadStatusMessage = "";
							}
						});
						break;
					case 'SUCCESS':
						$scope.getAllItems();
						$scope.getAllList();
					case 'FAILED':
						$scope.UploadStatusMessage = "Import  " + data.Status.toLowerCase() + "  !!!!";
						$scope.showConfirmationPopUp({
							title: "Import  " + data.Status.toLowerCase() + "  !!!!",
							message: data.message,
							okText: "ok",
							onSuccess: function () {
								$scope.clearFileField();
								$scope.UploadStatusMessage = "";
							}
						});
						break;
				}
			}

			$scope.clearFileField = function () {
				$("#tourZip")[0].value = "";
				formData = null;
			};

			function forceImportTourZip(params, callback) {
				$scope.UploadStatusMessage = "OverWriting Tours ....";
				invoke('/service/hikes', 'importTour', params, function (err, data) {
					callback(data);
				});
			}

			function getEmptyCondition() {
				var emptyTourCondition = {
					"attributes": {
						"conditionId": "",
						"conditionType": "",
						"launchCondition": ""
					},
					"args": [],
					"hideInMenu": false
				};
				return emptyTourCondition;
			}

			$scope.isHelpNeeded = function (type) {
				if (!$scope.allList) {
					return;
				}

				if (type === 'card') {
					return Object.keys($scope.cardtoHikeMap).length !== $scope.allList.cards.length;
				} else {
					return Object.keys($scope.hiketoTourMap).length !== $scope.allList.hikes.length;
				}
			};

			$scope.cardsHelper = function () {
				var unusedCards = $scope.allList.cards.filter(function (cardid) {
					return !$scope.cardtoHikeMap[cardid];
				});
				var message = "We Have found<b> " + unusedCards.length + " unused cards </b> in the repository";

				unusedCards.map(function (cardid, index) {
					message += "<br>" + (index + 1) + ",\t " + cardid;
				});

				var undefinedCards = Object.keys($scope.cardtoHikeMap).filter(function (cardid) {
					return $scope.allList.cards.indexOf(cardid) < 0;
				});

				if (undefinedCards.length > 0) {
					message += "<br><br>We cannot find <b> " + undefinedCards.length + " Unknown cards </b> that are used in some of the hikes";
					undefinedCards.map(function (cardid, index) {
						message += "<br>" + (index + 1) + ",\t " + cardid;
					});
				}

				$scope.showConfirmationPopUp({
					title: "Cards Information",
					message: message
				});
			};

			$scope.hikesHelper = function () {
				var unusedHikes = $scope.allList.hikes.filter(function (hikeId) {
					return !$scope.hiketoTourMap[hikeId];
				});
				var message = "We Have found<b> " + unusedHikes.length + " unused hikes </b> in the repository";

				unusedHikes.map(function (hikeId, index) {
					message += "<br>" + (index + 1) + ",\t " + hikeId;
				});

				var undefinedHikes = Object.keys($scope.hiketoTourMap).filter(function (hikeId) {
					return $scope.allList.hikes.indexOf(hikeId) < 0;
				});

				if (undefinedHikes.length > 0) {
					message += "<br><br>We cannot find <b> " + undefinedHikes.length + " hikes</b>  that are used in some of the hikes";
					undefinedHikes.map(function (hikeId, index) {
						message += "<br>" + (index + 1) + ",\t " + hikeId;
					});
				}

				$scope.showConfirmationPopUp({
					title: "Cards Information",
					message: message
				});
			};

			$scope.changeCardView = function () {
				$scope.isCardPreviewModeEnabled = !$scope.isCardPreviewModeEnabled;
				$scope.apply();
			};

			$scope.htmlBind = function (htmlSTring) {
				return $sce.trustAsHtml(htmlSTring);
			};

			$scope.ishikeModified = function (hikeId) {
				if (hikeId) {
					if ($scope.modifiedObjects.hikes.indexOf(hikeId) !== -1) {
						return "modified";
					}
				}
				return "";
			};

			$scope.istourModified = function (tourId) {
				if (tourId) {
					if ($scope.modifiedObjects.tours.indexOf(tourId) !== -1) {
						return "modified";
					}
				}
				return "";
			};

			$scope.isSettingsModified = function () {
				if ($scope.settingsPopup && ($scope.settings.BuilderWorkspace !== $scope.settingsPopup.BuilderWorkspace)) {
					return "modified";
				}
				return "";
			};

			$scope.removeFromModified = function (id, type) {
				$scope.modifiedObjects[type + "s"] = $scope.modifiedObjects[type + "s"].filter(v => v !== id);
			};

			$scope.discardChanges = function (id, type) {
				$scope.getItem({ id: id, type: type }, function () {
					$scope.removeFromModified(id, type);
				}, true);
			};

			$scope.getItem = function (item, cb, fromServer) {
				var id = item.id;
				var type = item.type + "s";
				if (!fromServer && $scope.allItems[type][id]) {
					cb && cb($scope.allItems[type][id]);
				}
				else {
					invoke('/service/hikes', 'get' + item.type, { 'id': id }, function (err, data) {
						$scope.allItems[type][id] = data;
						cb && cb($scope.allItems[type][id]);
					});
				}
			};

			$scope.getActualItem = function (item, cb) {
				var id = item.id;
				invoke('/service/hikes', 'getActual' + item.type, { 'id': id }, function (err, data) {
					if (!err) {
						cb && cb(data);
					}
				});
			};

			$scope.getElement = function (card, type) {
				getVizElement(function (value) {
					if (type === 'element') {
						card.pointer.element = value;
					} else if (type === 'navigationCondition') {
						card.navigationCondition = value;
					}
					$scope.apply();
				});
			};

			$scope.popUpCard = null;
			$scope.oldPopUpCardData = null;
			$scope.updateCardOnPopUp = function (id) {
				$scope.getItem({
					id: id,
					type: 'card'
				}, function (card) {
					showCardEditPopUp(id, card);
				});
			};

			$scope.updateRenamePopUp = function (id, type) {
				$scope.getItem({
					id: id,
					type: type
				}, function (hike) {
					showRenamePopUp(id, hike);
				});
			};

			$scope.AddArgsToCondition = function () {
				$scope.conditionPopUp.args.push({ name: "", value: "" });
			};

			function showCardEditPopUp(id, card) {
				$scope.popUpCard = card;
				$scope.oldPopUpCardData = JSON.parse(JSON.stringify($scope.popUpCard));
				$scope.apply();
			}

			$scope.previewCard = function (cardName) {
				$scope.card = cardName;
				$scope.apply();
			};

			$scope.showConfirmationPopUp = function (messageObj) {
				$scope.confirmationPopUp = messageObj;
				$scope.apply();
			};


			$scope.showSettingsPopUp = function (forceShow) {
				if (forceShow || !$scope.settings.dontShowOnLaunch) {
					$scope.settingsPopup = JSON.parse(JSON.stringify($scope.settings));
					$scope.apply();
				}
			};

			function showRenamePopUp(id, hike) {
				$scope.renamePopUp = hike;
				$scope.oldrenamePopUp = JSON.parse(JSON.stringify($scope.renamePopUp));
			}

			function showConditionPopUp(id, condition) {
				$scope.conditionPopUp = JSON.parse(JSON.stringify(condition));
				$scope.oldconditionPopUp = JSON.parse(JSON.stringify(condition));
			}

			function showEditPopUp(type) {
				var text = "";
				if (type === 'element') {
					text = $scope.popUpCard.pointer.element;
				} else if (type === 'navigationCondition') {
					text = $scope.popUpCard.navigationCondition;
				} else if (type === 'context') {
					text = $scope.popUpCard.context;
				}

				if (typeof (text) === 'object') {
					text = JSON.stringify(text, null, 4);
				}

				$scope.editElement = {
					type: type,
					text: text
				};
				$scope.apply();
			}

			$scope.editCardElement = function (type) {
				showEditPopUp(type);
			};

			$scope.AddNewKeyToMeta = function () {
				var newItem = {
					key: "newKey" + $scope.metaEditData.meta.length,
					value: "new Value"
				};
				$scope.metaEditData.meta.push(newItem);
			};

			$scope.editMeta = function (rootObject) {
				var meta = [];
				if (rootObject.meta) {
					Object.keys(rootObject.meta).map(function (metaKey) {
						meta.push({ key: metaKey, value: rootObject.meta[metaKey] });
					});
				}
				$scope.metaEditData = {
					meta: meta,
					source: rootObject
				};
			};

			$scope.onMetaEditPopupExit = function (action) {
				if (action === "save") {
					var meta = {};
					$scope.metaEditData.meta.map(function (item) {
						meta[item.key] = item.value;
					});
					$scope.metaEditData.source.meta = meta;
				}
				$scope.metaEditData = null;
			};

			$scope.updatehikeOnPopUp = function (id) {
				var popUpHikeEle = document.getElementById("hike-PopUp" + id);

				if (popUpHikeEle.style.display && popUpHikeEle.style.display === "block") {
					popUpHikeEle.style.display = "none";
				} else {
					$scope.getItem({
						id: id,
						type: 'hike'
					}, function (card) {
						initializetree(id, "hike");
						$scope.popUpHike = card;
						$scope.oldPopUpHikeData = JSON.parse(JSON.stringify($scope.popUpHike));
						popUpHikeEle.style.display = "block";
					});
				}
			};

			$scope.updateTourOnPopUp = function (id) {
				var popUpTourEle = document.getElementById("tour-PopUp" + id);

				if (popUpTourEle.style.display && popUpTourEle.style.display === "block") {
					popUpTourEle.style.display = "none";
				} else {
					$scope.getItem({
						id: id,
						type: 'tour'
					}, function (tour) {
						initializetree(id, "tour");
						$scope.popUpTour = tour;
						$scope.oldPopUpHikeData = JSON.parse(JSON.stringify($scope.popUpTour));
						popUpTourEle.style.display = "block";
					});
				}
			};

			$scope.getAllSubItems = function (id, type) {
				if (!id) { return; }
				if (type === 'cards') {
					type = 'card';
				} else if (type === 'hikes') {
					type = 'hike';
				} else if (type === 'tours') {
					type = 'tour';
				}
				$scope.getItem({
					id: id,
					type: type
				}, function (tour) {
					if (tour.type && tour.type !== 'card') {
						tour.consequent.map(function (item) {
							$scope.getAllSubItems(item.id, item.type);
						});
						tour.alternative.map(function (item) {
							$scope.getAllSubItems(item.id, item.type);
						});
					}
				});
			};

			function getNewCardId(id) {
				var newId = id;
				var i = 1;
				while ($scope.allList.cards.indexOf(newId) > -1) {
					newId = id + "_" + i;
					i++;
				}
				return newId;
			}

			$scope.createDuplicateCard = function (id, hikeId) {
				var newCardData = JSON.parse(JSON.stringify($scope.allItems.cards[id]));

				newCardData.id = getNewCardId(id);
				newCardData.kuid = getGuid();

				$scope.hikeIdToUpdateCardInHike = hikeId;
				showCardEditPopUp(id, newCardData);
				$scope.apply();
			};

			$scope.AddNewCard = function (id, hikeId) {
				id = getNewCardId(id);
				var newCardData = {
					"kuid": getGuid(),
					"id": id,
					"content": {
						"title": "Card Title",
						"body": "Card Information Body"
					},
					"pointer": {
						"direction": "left",
						"element": "",
						"type": "none"
					},
					"navigationType": "manual",
					"navigationBar": {
						"left": {
							"text": "Previous",
							"enable": true,
							"hide": false
						},
						"right": {
							"text": "Next",
							"enable": true,
							"hide": false
						}
					},
					"navigationCondition": "",
					"position": "BOTTOM_RIGHT",
					"meta": {
						"Creator": $scope.userName,
						"CreatedOn": (new Date()).toUTCString()
					},
					"context": []
				};

				$scope.hikeIdToUpdateCardInHike = hikeId;
				showCardEditPopUp(id, newCardData);
				$scope.apply();
			};

			$scope.insertInterLink = function (card) {
				card.content.body += '<a class="tour-link" tour="YOUR_TOUR_ID_HERE">Text To Start Tour</a>';
			};

			$scope.AddNewHike = function (id, tourId, index, condition) {
				if ($scope.allList.hikes.indexOf(id) > -1) {
					var newId = id;
					var i = 1;
					while ($scope.allList.hikes.indexOf(newId) > -1) {
						newId = id + "_" + i;
						i++;
					}
					id = newId;
				}
				var newHikeData = {
					"id": id,
					"kuid": getGuid(),
					"type": "hike",
					"title": id,
					"description": " Description of hike",
					"meta": {
						"Creator": $scope.userName,
						"CreatedOn": (new Date()).toUTCString()
					},
					"consequent": [],
					"alternative": []
				};

				$scope.tourToUpdateHikeInTour = {
					id: tourId,
					index: index,
					condition: condition
				};
				showRenamePopUp(id, newHikeData);
				$scope.apply();
			};

			$scope.AddNewTour = function (id) {
				if ($scope.allList.tours.indexOf(id) > -1) {
					var newId = id;
					var i = 1;
					while ($scope.allList.tours.indexOf(newId) > -1) {
						newId = id + "_" + i;
						i++;
					}
					id = newId;
				}
				var newTourData = {
					"id": id,
					"kuid": getGuid(),
					"type": "tour",
					"title": id,
					"description": " Description of Tour",
					"meta": {
						"Creator": $scope.userName,
						"CreatedOn": (new Date()).toUTCString()
					},
					"consequent": [],
					"alternative": []
				};
				showRenamePopUp(id, newTourData);
				$scope.apply();
			};

			$scope.AddNewCondition = function (id, tourIndex) {
				id = id + Date.now();

				var newConditionData = {
					attributes: {
						conditionId: id,
						conditionType: "",
						launchCondition: ""
					},
					args: [],
					type: "if",
					consequent: [],
					alternative: []
				};
				$scope.conditionToUpdateInTour = tourIndex;

				showConditionPopUp(id, newConditionData);
				$scope.apply();
			};

			$scope.editCondition = function (tourIndex) {
				var tour = $scope.allItems.tours[tourIndex.id];
				$scope.conditionToUpdateInTour = tourIndex;
				if (tourIndex.index !== undefined) {
					var condition = tour.consequent[tourIndex.index];
					showConditionPopUp(condition.attributes.conditionId, condition);
				} else {
					var entryCondition = tour.entryCondition || getEmptyCondition();
					showConditionPopUp(null, {
						attributes: entryCondition.attributes,
						args: entryCondition.args,
						type: 'entry'
					});
				}
				$scope.apply();
			};

			$scope.AddCardToHike = function (id, hikeId) {
				$scope.allItems.hikes[hikeId].consequent.push({
					id: id,
					type: 'card'
				});
				$scope.modifiedObjects.hikes.push(hikeId);
			};

			function removeValuefromArray(arr, val) {
				var index = arr.indexOf(val);
				if (index !== -1) {
					arr.splice(index, 1);
				}
			}

			$scope.deleteItem = function (id, type) {
				processItemMaps($scope.allItems);
				var customNote = "";
				if (type === 'card') {
					if ($scope.cardtoHikeMap[id] && $scope.cardtoHikeMap[id].length !== 0) {
						customNote = "<b>\"" + id
							+ '"</b> is used in below Hikes<b>'
							+ $scope.cardtoHikeMap[id].map(function (hike, index) {
								return "<br>" + (index + 1) + ". " + hike + "";
							}).join("") + "</b>";
					}
				} else if (type === 'hike') {
					if ($scope.hiketoTourMap[id] && $scope.hiketoTourMap[id].length !== 0) {
						customNote = "<b>\"" + id
							+ '"</b> is used in Below Tours<b>'
							+ $scope.hiketoTourMap[id].map(function (tour, index) {
								return "<br>" + (index + 1) + ". " + tour + "";
							}).join("") + "</b>";
					}
				}
				if (customNote !== "") {
					customNote = "<br>Please clean appropriate referances in "
						+ (type === 'card' ? 'hike' : 'tour')
						+ "<br>" + customNote;
				}
				$scope.showConfirmationPopUp({
					title: "Delete",
					message: "Do you want to delete <b> \"" + id + "\"</b> " + type + " ? " + customNote,
					okText: "Delete",
					cancelText: "Cancel",
					onSuccess: function () {
						var itemType = type + "s";
						invoke('/service/hikes', 'delete', {
							'id': id,
							'type': itemType
						}, function (err, data) {
							if (err) {

							} else {
								var AllLists = $scope.allList[itemType];
								var modifiedList = $scope.modifiedObjects[itemType];

								removeValuefromArray(AllLists, id);
								removeValuefromArray(modifiedList, id);

								if ($scope.allItems[itemType][id]) {
									delete $scope.allItems[itemType][id];
								}
							}
						});
					}
				});
			};

			$scope.getCard = function (id, cb, isSync) {
				if (isSync) {
					return $scope.allItems['cards'][id];
				} else {
					$scope.getItem({
						id: id,
						type: 'card'
					}, cb);
				}
			};

			$scope.getHike = function (id, cb, isSync) {
				if (isSync) {
					return $scope.allItems['hikes'][id];
				} else {
					$scope.getItem({
						id: id,
						type: 'hike'
					}, cb);
				}
			};

			$scope.getTour = function (id, cb, isSync) {
				if (isSync) {
					return $scope.allItems['tour'][id];
				} else {
					$scope.getItem({
						id: id,
						type: 'tour'
					}, cb);
				}
			};

			$scope.onCardPopupExit = function (action) {
				var id = $scope.popUpCard.id;
				var oldId = $scope.oldPopUpCardData.id;
				if (action === 'save') {
					var kuid = $scope.popUpCard.kuid.split(" ").join('');
					if ($scope.popUpCard.kuid.length !== 32 || kuid !== $scope.popUpCard.kuid) {
						$scope.popUpCard.kuid = kuid.length > 32 ? kuid.substring(0, 32) : getGuid();
					}
					SaveCardPopUp(id, oldId);
				} else {
					$scope.allItems['cards'][oldId] = $scope.oldPopUpCardData;
					closeCardPopUP(null, oldId);
				}
			};

			$scope.onEditElementPopupExit = function (action) {
				if (action === 'save') {
					$scope.SaveEditElementChanges();
				} else {
					closeEditElementPopUp();
				}
			};

			$scope.onSettingsPopupExit = function (action) {
				if (action === 'save') {
					$scope.settings = $scope.settingsPopup;
					$scope.saveSettings($scope.settings, function () {
						closeSettingsPopup();
					});
				} else if ($scope.settings.dontShowOnLaunch !== $scope.settingsPopup.dontShowOnLaunch) {
					$scope.settings.dontShowOnLaunch = $scope.settingsPopup.dontShowOnLaunch;
					$scope.saveSettings($scope.settings, function () {
						closeSettingsPopup();
					});
				} else {
					closeSettingsPopup();
				}
			};

			function isJson(str) {
				try {
					JSON.parse(str);
				} catch (e) {
					return false;
				}
				return true;
			}

			$scope.saveSettings = function (settings, callback) {
				invoke('/service/hikes', 'updateSettings', settings, function (err, data) {
					if (data) {
						$scope.settings = data;
						callback && callback();
					}
				});
			};

			$scope.SaveEditElementChanges = function () {
				var type = $scope.editElement.type;
				var text = $scope.editElement.text;

				if (isJson(text)) {
					text = JSON.parse(text);
				}

				if (type === 'element') {
					$scope.popUpCard.pointer.element = text;
				} else if (type === 'navigationCondition') {
					$scope.popUpCard.navigationCondition = text;
				} else if (type === 'context') {
					$scope.popUpCard.context = text;
				}
				closeEditElementPopUp();
			};

			$scope.downloadItem = function (itemName, itemType) {
				function getItemAndDownload() {
					$scope.getActualItem({
						id: itemName,
						type: itemType
					}, function (data) {
						DownloadItem(itemName, data, itemType);
					});
				}
				var isItemModified = false;
				switch (itemType) {
					case 'card':
						break;
					case 'hike':
						isItemModified = ($scope.ishikeModified(itemName) !== "");
						break;
					case 'tour':
						isItemModified = ($scope.istourModified(itemName) !== "");
						break;
				}
				if (isItemModified) {
					$scope.showConfirmationPopUp({
						title: "Download",
						message: "The are unsaved changed in " + itemName
							+ " " + itemType
							+ " . Download of item is always from physical location. Do you want to proceeed?",
						okText: "Download",
						cancelText: "Cancel",
						onSuccess: getItemAndDownload
					});
				} else {
					getItemAndDownload();
				}
			};

			$scope.onRenamePopupExit = function (action) {
				var id = $scope.renamePopUp.id;
				var oldId = $scope.oldrenamePopUp.id;
				var type = $scope.oldrenamePopUp.type;
				if (action === 'save') {
					$scope.saveChanges(id, oldId, type);
				} else {
					$scope.allItems[type + 's'][oldId] = $scope.renamePopUp;
					closeRenamePopUP(null, oldId);
				}
			};

			$scope.onConditionPopupExit = function (action) {
				if (action === 'save') {
					saveConditionChanges();
				} else {
					closeConditionPopUP();
				}
			};

			$scope.onConfirmationPopupExit = function (action) {
				if (action === 'ok') {
					$scope.confirmationPopUp.onSuccess && $scope.confirmationPopUp.onSuccess();
				} else {
					$scope.confirmationPopUp.onFailure && $scope.confirmationPopUp.onFailure();
				}
				$scope.confirmationPopUp = null;
			};

			$scope.moveCard = function (cardIndex, hikeId, direction) {
				var newIndex = cardIndex;
				switch (direction) {
					case "up":
						if (cardIndex !== 0) {
							newIndex -= 1;
						}
						break;
					case "down":
						if (cardIndex !== $scope.allItems.hikes[hikeId].consequent.length - 1) {
							newIndex += 1;
						}
						break;
				}
				if (cardIndex !== newIndex) {
					var temp = $scope.allItems.hikes[hikeId].consequent[newIndex];
					$scope.allItems.hikes[hikeId].consequent[newIndex] = $scope.allItems.hikes[hikeId].consequent[cardIndex];
					$scope.allItems.hikes[hikeId].consequent[cardIndex] = temp;
					$scope.modifiedObjects.hikes.push(hikeId);
					$scope.apply();
				}
			};

			$scope.getHikeListFromCondition = function (tourId, conditionIndex, conditionType) {
				if (conditionIndex) {
					if (conditionType === "true") {
						return $scope.allItems.tours[tourId].consequent[conditionIndex].consequent;
					} else {
						return $scope.allItems.tours[tourId].consequent[conditionIndex].alternative;
					}
				} else {
					return $scope.allItems.tours[tourId].consequent;
				}
			};

			$scope.moveHike = function (hikeIndex, tourId, direction, conditionIndex, conditionType) {
				var ActualListObj = $scope.getHikeListFromCondition(tourId, conditionIndex, conditionType);
				var newIndex = hikeIndex;
				switch (direction) {
					case "up":
						if (hikeIndex !== 0) {
							newIndex -= 1;
						}
						break;
					case "down":
						if (hikeIndex !== ActualListObj.length - 1) {
							newIndex += 1;
						}
						break;
				}

				if (hikeIndex !== newIndex) {
					var temp = ActualListObj[newIndex];
					ActualListObj[newIndex] = ActualListObj[hikeIndex];
					ActualListObj[hikeIndex] = temp;
					$scope.modifiedObjects.tours.push(tourId);
					$scope.apply();
				}
			};

			$scope.removeCardFromHike = function (cardIndex, hikeId) {
				$scope.allItems.hikes[hikeId].consequent.splice(cardIndex, 1);
				$scope.modifiedObjects.hikes.push(hikeId);
				$scope.apply();
			};

			$scope.removeHikeFromTour = function (hikeIndex, tourId, conditionIndex, conditionType) {
				var ActualListObj = $scope.getHikeListFromCondition(tourId, conditionIndex, conditionType);
				ActualListObj.splice(hikeIndex, 1);
				$scope.modifiedObjects.tours.push(tourId);
				$scope.apply();
			};

			function SaveCardPopUp(id, oldId) {
				invoke('/service/hikes', 'updateCard', {
					'id': id,
					'oldId': oldId,
					'card': $scope.popUpCard
				}, function (err, data) {
					if (err) {
						$scope.allItems['cards'][oldId] = $scope.oldPopUpCardData;
						closeCardPopUP("Failed to Save data", oldId);
					}
					else {
						if ($scope.hikeIdToUpdateCardInHike) {
							$scope.AddCardToHike(id, $scope.hikeIdToUpdateCardInHike);
							$scope.hikeIdToUpdateCardInHike = null;
						}

						if ($scope.allItems['cards'][oldId]) {
							delete $scope.allItems['cards'][oldId];
						}

						$scope.allItems['cards'][id] = $scope.popUpCard;
						$scope.allList.cards = $scope.allList.cards.filter(v => v !== oldId);
						$scope.allList.cards.push(id);

						closeCardPopUP("Successfully updated Card " + id, id);
					}
				});
			}

			$scope.AddHikeToTour = function (hikeId, tourIndex) {
				var tour = $scope.allItems.tours[tourIndex.id];
				if (!tour) {
					return;
				}

				if (tourIndex.index === undefined) {
					tour.consequent.push({ id: hikeId, type: 'hike', consequent: [], alternative: [] });
				} else {
					if (tourIndex.condition) {
						tour.consequent[tourIndex.index].consequent.push({ id: hikeId, type: 'hike', consequent: [], alternative: [] });
					} else {
						tour.consequent[tourIndex.index].alternative.push({ id: hikeId, type: 'hike', consequent: [], alternative: [] });
					}
				}
				$scope.modifiedObjects.tours.push(tourIndex.id);
				$scope.apply();
			};

			function saveChanges(id, oldId, type) {
				var data = $scope.allItems[type + 's'][oldId];
				if (!data) {
					data = $scope.renamePopUp;
				}
				id = data.title.split(" ").join('').substring(0, 36);
				data.id = id;
				var kuid = data.kuid.split(" ").join('');
				if (data.kuid.length !== 32 || kuid !== data.kuid) {
					data.kuid = kuid.length > 32 ? kuid.substring(0, 32) : getGuid();
				}
				var params = {
					'id': id,
					'oldId': oldId
				};

				params[type] = data;
				var func = type === 'hike' ? 'updateHike' : 'updateTour';
				invoke('/service/hikes', func, params, function (err, resp) {
					if (err) {
						$scope.allItems[type + 's'][oldId] = $scope.oldrenamePopUp;
						closeRenamePopUP("Failed to Save data", oldId);
					}
					else {
						if ($scope.allItems[type + 's'][oldId]) {
							delete $scope.allItems[type + 's'][oldId];
						}
						$scope.removeFromModified(id, type);

						$scope.allItems[type + 's'][id] = data;
						$scope.allList[type + 's'] = $scope.allList[type + 's'].filter(v => v !== oldId);
						$scope.allList[type + 's'].push(id);

						if ($scope.tourToUpdateHikeInTour) {
							$scope.AddHikeToTour(id, $scope.tourToUpdateHikeInTour);
							$scope.tourToUpdateHikeInTour = null;
						}

						closeRenamePopUP("Successfully updated Card " + id, id);
					}
				});
			}

			function saveConditionChanges() {

				if ($scope.conditionToUpdateInTour) {
					var tourIndex = $scope.conditionToUpdateInTour;
					var tour = $scope.allItems.tours[tourIndex.id];

					if (tourIndex.index === undefined) {
						if (tourIndex.type === 'entry') {
							// updating and existing entry condition
							tour.entryCondition = $scope.conditionPopUp;
						} else {
							//incase of new condition
							tour.consequent.push($scope.conditionPopUp);
						}
					} else {
						tour.consequent[tourIndex.index] = $scope.conditionPopUp;
					}
					$scope.modifiedObjects.tours.push(tourIndex.id);
					$scope.apply();
				}
				closeConditionPopUP();
			}

			$scope.saveChanges = function (id, oldId, type) {
				oldId = oldId ? oldId : id;
				saveChanges(id, oldId, type);
			};

			$scope.onCardPreviewPopupExit = function () {
				$scope.card = null;
			};

			function getGuid() {
				return 'xxxxxxtx-xxax-4xrx-yxux-xxxxxxnx'.replace(/[xy]/g, function (c) {
					var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
					return v.toString(16);
				});
			}

			function closeCardPopUP(message, id) {
				if (message) {
					showMessageOnFooter(message);
				}
				setTimeout(() => {
					var newCard = document.getElementById("card" + id);
					if (newCard) {
						newCard.scrollIntoViewIfNeeded();
					}
				}, 300);
				$scope.popUpCard = null;
			}

			function closeRenamePopUP(message, id) {
				if (message) {
					showMessageOnFooter(message);
				}
				if ($scope.renamePopUp) {
					var type = $scope.renamePopUp.type;
					setTimeout(() => {
						var newItem = document.getElementById(type + id);
						if (newItem) {
							newItem.scrollIntoViewIfNeeded();
						}
					}, 300);
				}
				$scope.renamePopUp = null;
			}

			function closeConditionPopUP(message, id) {
				$scope.conditionPopUp = null;
				if (message) {
					showMessageOnFooter(message);
				}
			}

			function closeEditElementPopUp() {
				$scope.editElement = null;
			}

			function closeSettingsPopup() {
				$scope.settingsPopup = null;
			}

			function AddItemToArray(arr, Item) {
				if (arr.indexOf(Item) < 0) {
					arr.push(Item);
				}
			}

			function processItemMaps(Items) {
				$scope.hiketoTourMap = {};
				$scope.cardtoHikeMap = {};
				Object.keys(Items.hikes).forEach(function (key) {
					var hike = Items.hikes[key];
					hike.consequent.map(function (card) {
						if (card.type === 'card') {
							$scope.cardtoHikeMap[card.id] = $scope.cardtoHikeMap[card.id] || [];
							AddItemToArray($scope.cardtoHikeMap[card.id], hike.id);
						} else {
							console.log("I am Here too");
						}
					});
				});

				Object.keys(Items.tours).forEach(function (key) {
					var tour = Items.tours[key];
					tour.consequent.map(function (hike) {
						if (hike.type === 'hike') {
							$scope.hiketoTourMap[hike.id] = $scope.hiketoTourMap[hike.id] || [];
							AddItemToArray($scope.hiketoTourMap[hike.id], tour.id);
						} else if (hike.type === 'if') {
							hike.consequent.map(function (hikeItem) {
								if (hikeItem.type === 'hike') {
									$scope.hiketoTourMap[hikeItem.id] = $scope.hiketoTourMap[hikeItem.id] || [];
									AddItemToArray($scope.hiketoTourMap[hikeItem.id], tour.id);
								} else {
									console.log(" i am here");
								}

							});
							hike.alternative.map(function (hikeItem) {
								if (hikeItem.type === 'hike') {
									$scope.hiketoTourMap[hikeItem.id] = $scope.hiketoTourMap[hikeItem.id] || [];
									AddItemToArray($scope.hiketoTourMap[hikeItem.id], tour.id);
								} else {
									console.log(" i am here");
								}
							});
						}
					});
				});
			}
			$scope.getAllItems = function () {
				invoke('/service/hikes', 'getAllItems', {}, function (err, data) {
					$scope.allItems = data;
					processItemMaps(data);
				});
			};

			$scope.getAllList = function () {
				invoke('/service/hikes', 'getAllList', {}, function (err, data) {
					$scope.allList = data;
				});
			};

			$scope.getSettings = function () {
				invoke('/service/hikes', 'getSettings', {}, function (err, data) {
					$scope.settings = data;
					ShowBuilder();
				});
			};

			$scope.exportData = function (id, itemType, tourKUID) {
				invoke('/service/hikes', 'export', {
					'id': id,
					'type': itemType
				}, function (err, data) {
					var str = atob(data); // creates a ASCII string
					var buffer = new ArrayBuffer(str.length),
						view = new Uint8Array(buffer);
					for (var i = 0; i < str.length; i++) {
						view[i] = str.charCodeAt(i);
					}

					const composerHost = "http://localhost:3200";

					$http
						.post(`${composerHost}/api/file/checksum`, {
						data,
						id,
						})
						.then(
							function onSuccess(resp) {
								const checksum = resp.data.checksum;
								window.open(
								`${composerHost}/composer?checksum=${checksum}&kuid=${tourKUID}&zipName=${id}`,
								"",
								"width=1024, height=768"
								);
							},
							function onFailure(resp) {
								alert(`Failed to connect ${composerHost}`);
							}
						);

					// disabled downloading the tour zip file
					// saveByteArray([view], id + '.zip');
				});
			};

			var saveByteArray = (function () {
				var a = document.createElement("a");
				document.body.appendChild(a);
				a.style = "display: none";
				return function (data, name) {
					var blob = new Blob(data, { type: "application/zip" }),
						url = window.URL.createObjectURL(blob);
					a.href = url;
					a.download = name;
					a.click();
					window.URL.revokeObjectURL(url);
				};
			}());

			function init() {
				$scope.getSettings();
				$scope.getAllItems();
				$scope.getAllList();
			}

			init();

			function invoke(serviceURL, serviceName, params, cb) {
				$http
					.post(
						serviceURL
						, {
							data: {
								func: serviceName,
								params: params
							}
						}
					)
					.then(
						function onSuccess(resp) {
							cb && cb(null, resp.data);
						}, function onFailure(resp) {
							console.log("cannot call method" + resp);
						}
					);
			}
		})
	;
