const splashScreen = document.getElementById("splash-screen");
const mainScreen = document.getElementById("main-screen");
var angularScope = angular.element(splashScreen).scope();

let exportTourKUID = "";

/**
 * ANIMATE CSS JQUERY REGSITER
 */
var getElementCB = null;

function getAngularScope() {
	if (!angularScope) {
		angularScope = angular.element(splashScreen).scope();
	}
	return angularScope;
}

window.KonyBot = {
	postToParent: function (msg) {
		var parentWindow = window.opener || window.parent;
		if (parentWindow === window) { return false; }

		parentWindow && parentWindow.postMessage(msg, '*');
	},
	hearFromParent: function (eventObj) {
		if (eventObj.data.messageType === "Text") {
			showMessageOnFooter(eventObj.data.text);
		} else if (eventObj.data.messageType === "vizElement") {
			parseMessage({
				messageType: eventObj.data.messageType,
				messageData: JSON.parse(eventObj.data.text)
			});
		} else if (eventObj.data.messageType === "userDetails") {
			getAngularScope().userName = eventObj.data.userDetails.username;
		}
	}
};
// Listen from messages from Visualzier
window.addEventListener("message", KonyBot.hearFromParent, false);

function initiateDomSelection() {
	KonyBot.postToParent({
		'command': 'initiateDomSelection'
	});
}

function stopDomSelection() {
	KonyBot.postToParent({
		'command': 'endDomSelection'
	});
}

function close() {
	KonyBot.postToParent({
		'command': 'close_hikeBuilder'
	});
}

function getUserDetails() {
	KonyBot.postToParent({
		'command': 'userDetails'
	});
}

getUserDetails();

function runpreviewTour(tourJSON) {
	KonyBot.postToParent({
		command: 'runTourPreview',
		tour: tourJSON
	});
}

$.fn.extend({
	animateCss: function (animationName, callback) {
		var animationEnd = (function (el) {
			var animations = {
				animation: 'animationend',
				OAnimation: 'oAnimationEnd',
				MozAnimation: 'mozAnimationEnd',
				WebkitAnimation: 'webkitAnimationEnd',
			};

			for (var t in animations) {
				if (el.style[t] !== undefined) {
					return animations[t];
				}
			}
		})(document.createElement('div'));

		this.addClass('animated ' + animationName).one(animationEnd, function () {
			$(this).removeClass('animated ' + animationName);

			if (typeof callback === 'function') { callback(); }
		});

		return this;
	},
});

/**
 * MASTER BODY ON CLICK REGISTER
 */

function getVizElement(cb) {
	initiateDomSelection();
	getElementCB = cb;
}

/**
 * PARSE MESSAGE RRECEIVE FROM SOCKET
 */

function parseMessage(m) {
	try {
		if (typeof m === typeof "string") {
			m = JSON.parse(m);
		}

		if (m.messageType) {
			switch (m.messageType) {
				case "vizElement":
					stopDomSelection();
					if (m.messageData.nodeToBeHighlighted) {
						delete m.messageData.nodeToBeHighlighted;
					}
					getElementCB && getElementCB(m.messageData);
					break;
				default:
					break;
			}
		}
	} catch (error) {
		console.log("unable to parse message received from server", error, m);
	}
}
var firstTimeLaunch = true;

function ShowBuilder() {
	if (firstTimeLaunch) {
		setTimeout(function () {
			$(splashScreen).animateCss("fadeOut", function () {
				mainScreen.style.display = "flex";
				$(mainScreen).animateCss("fadeIn");
				$(splashScreen).hide();
				getAngularScope().showSettingsPopUp();
			});
		}, 500);
		firstTimeLaunch = false;
	}
}

function scrollToNewlyAddedElement(e) {
	$('body, html').animate({ scrollTop: $(e).offset().top }, 500);
}

function copyKUIDtoClipBoard(item) {
	copyTextToClipBoard(item.kuid, (item.type ? item.type : "Card") + " KUID");
	if (item.type === "tour") {
		exportTourKUID = item.kuid;
	}
}

function copyCardConfig(cardConfig) {
	copyTextToClipBoard(JSON.stringify(cardConfig, null, 4), "Card Config");
}

function copyTextToClipBoard(textToCopy, Type) {
	const el = document.createElement('textarea');
	el.value = textToCopy;
	el.style.position = 'absolute';
	el.style.left = '-9999px';
	document.body.appendChild(el);
	el.select();
	document.execCommand('copy');
	document.body.removeChild(el);

	showMessageOnFooter(getAngularScope().$translate.instant('COPIED_TO_CLIPBOARD_FOOTER', { type: Type }));
}

function showMessageOnFooter(message) {
	var oldText = document.getElementById('footerText').textContent;
	document.getElementById('footerText').textContent = message;
	setTimeout(function () {
		document.getElementById('footerText').textContent = oldText;
	}, 2000);
}

function DownloadItem(itemName, itemData, type) {
	var element = document.createElement('a');
	if (type === "card") {
		element.setAttribute('href'
			, 'data:text/plain;charset=utf-8,'
			+ encodeURIComponent(JSON.stringify(itemData, null, 4))
		);
		element.setAttribute('download', itemName + '.json');
	} else {
		element.setAttribute('href'
			, 'data:text/plain;charset=utf-8,'
			+ encodeURIComponent(JSON.parse(itemData))
		);
		element.setAttribute('download', itemName + '.xml');
	}

	element.style.display = 'none';
	document.body.appendChild(element);

	element.click();
	document.body.removeChild(element);
}

$.fn.extend({
	treed: function (o) {

		var openedClass = 'glyphicon-minus-sign';
		var closedClass = 'glyphicon-plus-sign';

		if (typeof o !== 'undefined') {
			if (typeof o.openedClass !== 'undefined') {
				openedClass = o.openedClass;
			}
			if (typeof o.closedClass !== 'undefined') {
				closedClass = o.closedClass;
			}
		}

		//initialize each of the top levels
		var tree = $(this);
		if (tree.hasClass("tree")) {
			return;
		}
		tree.addClass("tree");
		tree.find('li').has("ul").each(function () {
			var branch = $(this); //li with children ul
			branch.prepend("<i class='indicator glyphicon " + closedClass + "'></i>");
			branch.addClass('branch');
			branch.on('click', function (e) {
				if (this === e.target) {
					var icon = $(this).children('i:first');
					icon.toggleClass(openedClass + " " + closedClass);
					$(this).children().children().toggle();
				}
			});
			branch.children().children().toggle();
		});
		//fire event from the dynamically added icon
		tree.find('.branch .indicator').each(function () {
			$(this).on('click', function () {
				$(this).closest('li').click();
			});
		});
		//fire event to open branch if the li contains an anchor instead of text
		tree.find('.branch>a').each(function () {
			$(this).on('click', function (e) {
				$(this).closest('li').click();
				e.preventDefault();
			});
		});
		//fire event to open branch if the li contains a button instead of text
		tree.find('.branch>button').each(function () {
			$(this).on('click', function (e) {
				$(this).closest('li').click();
				e.preventDefault();
			});
		});
	}
});

function initializetree(id, type) {
	//Initialization of treeviews
	$(document.getElementById("tree" + type + id)).treed();
}

$(function () {
	$.contextMenu({
		selector: '.context-menu-oncard',
		build: function ($trigger, e) {
			const $translate = getAngularScope().$translate;
			var cardName = $trigger[0].getAttribute("card-id");
			return {
				callback: function (key, options) {
					switch (key) {
						case "editCard":
							getAngularScope().updateCardOnPopUp(cardName);
							break;
						case "copyCard":
							getAngularScope().getCard(cardName, copyCardConfig);
							break;
						case "duplicateCard":
							getAngularScope().createDuplicateCard(cardName);
							break;
						case "downloadCard":
							getAngularScope().downloadItem(cardName, 'card');
							break;
						case "deleteCard":
							getAngularScope().deleteItem(cardName, "card");
							break;
						case "previewCard":
							getAngularScope().previewCard(cardName);
							break;
						case "copyKuid":
							getAngularScope().getCard(cardName, copyKUIDtoClipBoard);
							break;
						default:
							getAngularScope().AddCardToHike(cardName, key);
							getAngularScope().$apply();
							break;
					}
					var m = "clicked: " + key + "for card: " + cardName;
					console.log(m);
				},
				items: {
					"previewCard": { name: $translate.instant('CONTEXT_MENU_PREVIEW_CARD'), icon: "view" },
					"separator1": "-----",
					"editCard": { name: $translate.instant('CONTEXT_MENU_EDIT_CARD'), icon: "edit" },
					"copyCard": { name: $translate.instant('CONTEXT_MENU_COPY_CARD'), icon: "copy" },
					"copyKuid": { name: $translate.instant('CONTEXT_MENU_COPY_KUID'), icon: "copy" },
					"addCardToHike": {
						name: $translate.instant('CONTEXT_MENU_ADD_CARD_TO_HIKE'),
						icon: "plus",
						items: getHikesContextMenuAllItems(""),
						className: "limit-context-size"
					},
					"duplicateCard": { name: $translate.instant('CONTEXT_MENU_DUPLICATE_CARD'), icon: "clone" },
					"separator2": "-----",
					"downloadCard": { name: $translate.instant('CONTEXT_MENU_DOWNLOAD_CARD'), icon: "download" },
					"separator3": "-----",
					"deleteCard": { name: $translate.instant('CONTEXT_MENU_DELETE_CARD'), icon: "delete" },
				}
			};
		}

	});

	$.contextMenu({
		selector: '.context-menu-onhikecard',
		build: function ($trigger, e) {
			const $translate = getAngularScope().$translate;
			var cardName = $trigger[0].getAttribute("card-id");
			var cardIndex = parseInt($trigger[0].getAttribute("card-index"));
			var hikeName = $trigger[0].getAttribute("hike-id");
			return {
				callback: function (key, options) {
					switch (key) {
						case "moveup":
							getAngularScope().moveCard(cardIndex, hikeName, "up");
							break;
						case "movedown":
							getAngularScope().moveCard(cardIndex, hikeName, "down");
							break;
						case "edit":
							getAngularScope().updateCardOnPopUp(cardName, hikeName);
							break;
						case "remove":
							getAngularScope().removeCardFromHike(cardIndex, hikeName);
							break;
						case "previewCard":
							getAngularScope().previewCard(cardName);
							break;
						case "copyKuid":
							getAngularScope().getCard(cardName, copyKUIDtoClipBoard);
							break;
						case "downloadCard":
							getAngularScope().downloadItem(cardName, 'card');
							break;
					}
					var m = "clicked: " + key;
					console.log(m);
				},
				items: {
					"previewCard": { name: $translate.instant('CONTEXT_MENU_PREVIEW_CARD'), icon: "view" },
					"separator1": "-----",
					"edit": { name: $translate.instant('EDIT'), icon: "paste" },
					"copyKuid": { name: $translate.instant('CONTEXT_MENU_COPY_KUID'), icon: "copy" },
					"moveup": {
						name: $translate.instant('CONTEXT_MENU_MOVE_UP'), disabled: function () {
							return (cardIndex === 0);
						}
					},
					"movedown": {
						name: $translate.instant('CONTEXT_MENU_MOVE_DOWN'), disabled: function () {
							return (getAngularScope().allItems.hikes[hikeName].consequent.length === cardIndex + 1);
						}
					},
					"separator2": "-----",
					"downloadCard": { name: $translate.instant('CONTEXT_MENU_DOWNLOAD_CARD'), icon: "download" },
					"separator3": "-----",
					"remove": { name: $translate.instant('REMOVE'), icon: "delete" },
				}
			};
		}
	});

	function getCardsContextMenuAllItems(trigger) {
		var hikeName = trigger[0].textContent;
		var dataObj = {};
		var hike = getAngularScope().allItems.hikes[hikeName];
		var allCards = getAngularScope().allList.cards;
		var hikeCards = hike.consequent.map(function (card) { return card.id; }) || [];
		allCards.filter(v => hikeCards.indexOf(v) === -1)
			.map(function (cardid) {
				dataObj[cardid] = {
					name: cardid
				};
			});
		return dataObj;
	}

	$.contextMenu({
		selector: '.context-menu-onhike',
		build: function ($trigger, e) {
			const $translate = getAngularScope().$translate;
			var hikeName = $trigger[0].getAttribute("hike-id");
			var nodeName = $trigger[0].nodeName;
			var tourName = $trigger[0].getAttribute("tour-id");
			var hikeIndex = parseInt($trigger[0].getAttribute("hike-index"));
			var conditionIndex = parseInt($trigger[0].getAttribute("condition-index"));
			var conditionType = $trigger[0].getAttribute("condition-type");

			var isModified = getAngularScope().ishikeModified(hikeName) === "modified";
			var Items = {};
			Items["rename"] = { name: $translate.instant('CONTEXT_MENU_EDIT_HIKE'), icon: "edit" };
			if (nodeName !== "DIV") {
				Items["addcard"] = {
					name: $translate.instant('CONTEXT_MENU_ADD_CARD'), icon: "plus", items: {
						"addnewcard": { name: $translate.instant('CONTEXT_MENU_ADD_NEW_CARD') },
						"addexistingcard": {
							name: $translate.instant('CONTEXT_MENU_ADD_EXISTING_CARD'),
							items: getCardsContextMenuAllItems($trigger),
							className: "limit-context-size"
						}
					}
				};
				if (tourName) {
					Items["moveup"] = {
						name: $translate.instant('CONTEXT_MENU_MOVE_UP'), disabled: function () {
							return (hikeIndex === 0);
						}
					};
					Items["movedown"] = {
						name: $translate.instant('CONTEXT_MENU_MOVE_DOWN'), disabled: function () {
							return (getAngularScope().getHikeListFromCondition(tourName, conditionIndex, conditionType).length === hikeIndex + 1);
						}
					};
				} else {
					Items["addHikeToTour"] = {
						name: $translate.instant('CONTEXT_MENU_ADD_HIKE_TO_TOUR'),
						items: getToursContextMenuAllItems("tour:"),
						className: "limit-context-size"
					};
				}
			}
			Items["copyKuid"] = { name: $translate.instant('CONTEXT_MENU_COPY_KUID'), icon: "copy" };
			Items["separator1"] = "-----";
			Items["save"] = { name: $translate.instant('SAVE'), icon: "save", disabled: !isModified };
			Items["discard"] = { name: $translate.instant('DISCARD_CHANGES'), icon: "clean", disabled: !isModified };
			Items["delete"] = { name: $translate.instant('CONTEXT_MENU_DELETE_HIKE'), icon: "delete" };
			Items["remove"] = { name: $translate.instant('CONTEXT_MENU_REMOVE_HIKE'), icon: "clean" };
			Items["separator2"] = "-----";
			Items["download"] = { name: $translate.instant('DOWNLOAD'), icon: "download" };
			return {
				callback: function (key, options) {
					if (key.startsWith('tour:')) {
						var ToTourid = key.replace("tour:", "");
						getAngularScope().AddHikeToTour(hikeName, { id: ToTourid });
						getAngularScope().$apply();
						return;
					}

					switch (key) {
						case "addnewcard":
							var cardName = hikeName + "_Card";
							getAngularScope().AddNewCard(cardName, hikeName);
							break;
						case "save":
							getAngularScope().saveChanges(hikeName, hikeName, 'hike');
							break;
						case "discard":
							getAngularScope().discardChanges(hikeName, 'hike');
							break;
						case "delete":
							getAngularScope().deleteItem(hikeName, "hike");
							break;
						case "rename":
							getAngularScope().updateRenamePopUp(hikeName, 'hike');
							getAngularScope().$apply();
							break;
						case "download":
							getAngularScope().downloadItem(hikeName, 'hike');
							break;
						case "moveup":
							getAngularScope().moveHike(hikeIndex, tourName, "up", conditionIndex, conditionType);
							break;
						case "movedown":
							getAngularScope().moveHike(hikeIndex, tourName, "down", conditionIndex, conditionType);
							break;
						case "remove":
							getAngularScope().removeHikeFromTour(hikeIndex, tourName, conditionIndex, conditionType);
							break;
						case "copyKuid":
							getAngularScope().getHike(hikeName, copyKUIDtoClipBoard);
							break;
						default:
							var existingCardName = key;
							getAngularScope().AddCardToHike(existingCardName, hikeName);
							getAngularScope().$apply();
							break;
					}
					var m = "clicked: " + key + "for card: " + hikeName;
					console.log(m);
				},
				items: Items
			};
		}
	});

	function getToursContextMenuAllItems(appendText) {
		var dataObj = {};
		var allTours = getAngularScope().allList.tours;
		allTours.map(function (tourid) {
			var key = appendText + tourid;
			key = key.split().join();
			dataObj[key] = {
				name: tourid
			};
		});
		return dataObj;
	}

	function getHikesContextMenuAllItems(appendText) {
		var dataObj = {};
		var allHikes = getAngularScope().allList.hikes;
		allHikes.map(function (hikeid) {
			dataObj[appendText + hikeid] = {
				name: hikeid
			};
		});
		return dataObj;
	}

	$.contextMenu({
		selector: '.context-menu-ontour',
		build: function ($trigger, e) {
			const $translate = getAngularScope().$translate;
			var tourName = $trigger[0].getAttribute("tour-id");
			var nodeName = $trigger[0].nodeName;
			var isModified = getAngularScope().istourModified(tourName) === "modified";
			var Items = {};
			Items["entrycondition"] = { name: $translate.instant('CONTEXT_MENU_ENTRY_CONDITION'), icon: "" };
			Items["rename"] = { name: $translate.instant('CONTEXT_MENU_EDIT_TOUR'), icon: "edit" };
			Items["runtour"] = { name: $translate.instant('CONTEXT_MENU_PREVIEW_TOUR'), icon: "preview" };
			if (nodeName !== "DIV") {
				Items["addhike"] = {
					name: $translate.instant('CONTEXT_MENU_ADD_HIKE'), icon: "plus", items: {
						"addnewhike": { name: $translate.instant('CONTEXT_MENU_ADD_NEW_HIKE') },
						"addexistinghike": {
							name: $translate.instant('CONTEXT_MENU_ADD_EXISTING_HIKE'),
							items: getHikesContextMenuAllItems('ontour:hike:'),
							className: "limit-context-size"
						}
					}
				};
				Items["addcondition"] = {
					name: $translate.instant('CONTEXT_MENU_ADD_CONDITION'), icon: "plus", items: {
						"addnewcondition": { name: $translate.instant('CONTEXT_MENU_ADD_NEW_CONDITION') }
					}
				};
			} else {
			}
			Items["copyKuid"] = { name: $translate.instant('CONTEXT_MENU_COPY_KUID'), icon: "copy" };
			Items["separator1"] = "-----";
			Items["save"] = { name: $translate.instant('SAVE'), icon: "save", disabled: !isModified };
			Items["discard"] = { name: $translate.instant('DISCARD_CHANGES'), icon: "clean", disabled: !isModified };
			Items["delete"] = { name: $translate.instant('DELETE'), icon: "delete" };
			Items["separator2"] = "-----";
			Items["export"] = { name: $translate.instant('EXPORT'), icon: "export" };
			Items["download"] = { name: $translate.instant('DOWNLOAD'), icon: "download" };
			return {
				callback: function (key, options) {
					if (key.startsWith("ontour")) {
						var steps = key.split(":");
						if (steps[1] === "hike") {
							var existingCardName = steps[2];
							getAngularScope().AddHikeToTour(existingCardName, { id: tourName });
							getAngularScope().$apply();
						} else {
							var existingCardName = steps[2];
							getAngularScope().AddConditionToTour(existingCardName, { id: tourName });
							getAngularScope().$apply();
						}
					}
					switch (key) {
						case "runtour":
							getAngularScope().runTourPreview(tourName);
							break;
						case "addnewhike":
							var cardName = tourName + "_Hike";
							getAngularScope().AddNewHike(cardName, tourName);
							break;
						case "addnewcondition":
							var conditionName = "condition";
							getAngularScope().AddNewCondition(conditionName, { id: tourName });
							break;
						case "save":
							getAngularScope().saveChanges(tourName, tourName, 'tour');
							break;
						case "discard":
							getAngularScope().discardChanges(tourName, 'tour');
							break;
						case "delete":
							getAngularScope().deleteItem(tourName, "tour");
							break;
						case "rename":
							getAngularScope().updateRenamePopUp(tourName, 'tour');
							getAngularScope().$apply();
							break;
						case "export":
							getAngularScope().getTour(tourName, copyKUIDtoClipBoard);
							getAngularScope().exportData(tourName, "tour", exportTourKUID);
							break;
						case "refresh":
							getAngularScope().$apply();
							break;
						case "entrycondition":
							getAngularScope().editCondition({ id: tourName, type: "entry" });
							break;
						case "download":
							getAngularScope().downloadItem(tourName, 'tour');
							break;
						case "copyKuid":
							getAngularScope().getTour(tourName, copyKUIDtoClipBoard);
							break;
					}
					var m = "clicked: " + key + "for card: " + tourName;
					console.log(m);
				},
				items: Items
			};
		}
	});

	$.contextMenu({
		selector: '.context-update-vizElement',
		trigger: 'left',
		callback: function (key, options) {
			var type = options.$trigger[0].getAttribute("update-to");
			switch (key) {
				case "vizElement":
					getAngularScope().getElement(getAngularScope().popUpCard, type);
					break;
				case "Edit":
					getAngularScope().editCardElement(type);
					break;
			}
		},
		items: {
			"vizElement": { name: getAngularScope().$translate.instant('CONTEXT_MENU_GET_IRIS_ELEMENT'), icon: "cursor" },
			"Edit": { name: getAngularScope().$translate.instant('EDIT'), icon: "edit" },
		}
	});

	$.contextMenu({
		selector: '.context-update-oncondition',
		build: function ($trigger, e) {
			const $translate = getAngularScope().$translate;
			var tourName = $trigger[0].getAttribute("tour-id");
			var index = parseInt($trigger[0].getAttribute("index"));
			return {
				callback: function (key, options) {
					var hikeName = "";
					var selected = key;
					var tourIndex = {
						id: tourName,
						index: index
					};
					if (key.startsWith("my-condition")) {
						var steps = key.split(':');
						hikeName = steps[2];
						selected = 'addexistinghike';
						tourIndex.condition = steps[1] === 'true';
					}
					switch (selected) {
						case "addnewhike":
							hikeName = tourName + "_Hike";
							getAngularScope().AddNewHike(hikeName, tourName, index, true);
							break;
						case "addnewhikeonfalse":
							hikeName = tourName + "_Hike";
							getAngularScope().AddNewHike(hikeName, tourName, index, false);
							break;
						case "addexistinghike":
							getAngularScope().AddHikeToTour(hikeName, tourIndex);
							break;
						case "Edit":
							getAngularScope().editCondition(tourIndex);
							break;
						case "moveup":
							getAngularScope().moveHike(index, tourName, "up");
							break;
						case "movedown":
							getAngularScope().moveHike(index, tourName, "down");
							break;
						case "remove":
							getAngularScope().removeHikeFromTour(index, tourName);
							break;
					}
				},
				items: {
					"Edit": { name: $translate.instant('CONTEXT_MENU_EDIT_CONDITION'), icon: "edit" },
					"addhike": {
						name: $translate.instant('CONTEXT_MENU_ADD_HIKE'), icon: "add", items: {
							"addontrue": {
								name: $translate.instant('CONTEXT_MENU_ON_TRUE'), icon: "add", items: {
									"addnewhike": { name: $translate.instant('CONTEXT_MENU_ADD_NEW_HIKE') },
									"addexistinghike": {
										name: $translate.instant('CONTEXT_MENU_ADD_EXISTING_HIKE'),
										items: getHikesContextMenuAllItems('my-condition:true:'),
										className: "limit-context-size"
									}
								}
							},
							"addonfalse": {
								name: $translate.instant('CONTEXT_MENU_ON_FALSE'), icon: "add", items: {
									"addnewhikeonfalse": { name: $translate.instant('CONTEXT_MENU_ADD_NEW_HIKE') },
									"addexistinghike": {
										name: $translate.instant('CONTEXT_MENU_ADD_EXISTING_HIKE'),
										items: getHikesContextMenuAllItems('my-condition:false:'),
										className: "limit-context-size"
									}
								}
							}
						}
					},
					"separator1": "-----",
					"moveup": {
						name: $translate.instant('CONTEXT_MENU_MOVE_UP'), disabled: function () {
							return (index === 0);
						}
					},
					"movedown": {
						name: $translate.instant('CONTEXT_MENU_MOVE_DOWN'), disabled: function () {
							return (getAngularScope().allItems.tours[tourName].consequent.length === index + 1);
						}
					},
					"separator2": "-----",
					"remove": { name: $translate.instant('REMOVE') }
				}
			};
		}
	});
});
