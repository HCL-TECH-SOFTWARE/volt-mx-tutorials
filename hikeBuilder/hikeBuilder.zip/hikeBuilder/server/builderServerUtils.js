var fs = require('fs-extra')
	, path = require('path')
	, extractZip = require('extract-zip')
	, builderSettings = require('./builderSettings')
	, tourConvertor = require('./tourXML83to84Converter')
	, tourI18nConverter = require('./tourI18nConverter')
	, hikeBuilderUtils = require('./hikeBuilderUtils');

var ns = {};

(function (ns) {

	ns.Settings = null;

	ns.execFunction = function (data, callback) {

		var funcToExec = data.func;
		var params = data.params;
		switch (funcToExec) {
			case 'importTour':
				ns.importTour(params, true, function (data) {
					callback(JSON.stringify(data));
				});
				break;
			case 'getSettings':
				callback(JSON.stringify(builderSettings.getSettings()));
				break;
			case 'updateSettings':
				callback(JSON.stringify(builderSettings.updateSettings(params)));
				break;
			case 'getAllList':
				callback(JSON.stringify({
					tours: helpers.getToursList(builderSettings.TOURS_PATH),
					hikes: helpers.getHikesList(builderSettings.HIKES_PATH),
					cards: helpers.getCardsList(builderSettings.CARDS_PATH),
				}));
				break;
			case 'getAllItems':
				hikeBuilderUtils.getAllItems(function (data) {
					callback(JSON.stringify(data));
				});
				break;
			case 'gethike':
			case 'getcard':
			case 'gettour':
			case 'getActualcard':
			case 'getActualhike':
			case 'getActualtour':
				hikeBuilderUtils.getItemData(funcToExec, params)
					.then(function (data) {
						callback(JSON.stringify(data));
					});
				break;
			case 'getFullTour':
				hikeBuilderUtils.getItemData('gettour', params, true)
					.then(function (data) {
						callback(JSON.stringify(data));
					});
				break;
			case 'updateCard':
			case 'updateHike':
			case 'updateTour':
				callback(JSON.stringify(hikeBuilderUtils.updateItemData(funcToExec, params)));
				break;
			case 'delete':
				callback(JSON.stringify(hikeBuilderUtils.deleteItem(params)));
				break;
			case 'export':
				hikeBuilderUtils.exportItem(funcToExec, params, function (data) {
					callback(data);
				});
				break;
			default:
				callback(null);
				break;
		}
	};

	ns.evaluateZip = function (file, callback) {
		var sourcePath = file.path;
		ns.importTour(sourcePath, false, callback);
	};

	ns.importTour = function (sourcePath, overWriteFiles, callback) {
		var tempExtrachPath = path.resolve(builderSettings.UPLOADS_PATH, "temp");
		helpers.deleteItem(tempExtrachPath);
		extractZip(sourcePath, { dir: tempExtrachPath }, function (err) {
			if (!err) {
				var tourConfig = helpers.getTourConfig(tempExtrachPath);

				if (!tourConfig.isTourValid) {
					callback && callback({
						Status: "FAILED",
						message: "Invalid Tour Uploaded"
					});
					helpers.deleteItem(sourcePath);
					return;
				}
				if (overWriteFiles) {
					helpers.copyTourFiles(tourConfig.BaseDirPath, builderSettings.SOURCE_PATH, tourConfig);
					callback && callback({
						Status: "SUCCESS",
						message: "SuccesFully Imported"
					});
					helpers.deleteItem(sourcePath);
				} else {
					var sourceCardsList = helpers.getCardsList(builderSettings.CARDS_PATH);
					var sourceHikesList = helpers.getHikesList(builderSettings.HIKES_PATH);
					var sourceToursList = helpers.getToursList(builderSettings.TOURS_PATH);

					var newCardsList = helpers.getCardsList(path.resolve(tourConfig.BaseDirPath, "cards"));
					var newHikesList = helpers.getHikesList(path.resolve(tourConfig.BaseDirPath, "hikes"));
					var newToursList = helpers.getToursList(path.resolve(tourConfig.BaseDirPath, tourConfig.isTourSP4 ? "" : "tours"), tourConfig);

					var willUpdateList = {
						cards: helpers.compareLists(sourceCardsList, newCardsList),
						hikes: helpers.compareLists(sourceHikesList, newHikesList),
						tours: helpers.compareLists(sourceToursList, newToursList)
					};

					var isConfirmationRequired = false;
					Object.keys(willUpdateList).map(function (type) {
						if (willUpdateList[type].length > 0) {
							isConfirmationRequired = true;
						}
					});

					if (isConfirmationRequired) {
						callback && callback({
							Status: "PAUSED",
							message: "We have found some conflicts while Importing Tour. Do You Want to overwrite the current Tour With below Existing Items in Workspace?",
							data: willUpdateList,
							filePath: sourcePath
						});
					} else {
						helpers.copyTourFiles(tourConfig.BaseDirPath, builderSettings.SOURCE_PATH, tourConfig);
						callback && callback({
							Status: "SUCCESS",
							message: "SuccesFully Imported"
						});
						helpers.deleteItem(sourcePath);
					}
				}

			}
		});
	};

	var helpers = {
		getTourConfig: function (tourRootPath) {
			var config = {
				isTourValid: true,
				isTourSP4: undefined,
				BaseDirPath: "",
			};

			//Assuming Existance of only one folder in temp dir
			if (fs.existsSync(tourRootPath)) {
				var basedirList = fs.readdirSync(tourRootPath);
				config.BaseDirPath = basedirList.length === 1 ? basedirList[0] : null;
			}

			if (config.BaseDirPath) {
				config.isTourSP4 = config.BaseDirPath !== "guidedtours";
				config.BaseDirPath = path.resolve(tourRootPath, config.BaseDirPath);

				var dirList = fs.readdirSync(config.BaseDirPath);

				var requiredList = config.isTourSP4 ? ["cards", "hikes"] : ["cards", "hikes", "tours"];

				requiredList.map(function (item) {
					if (dirList.indexOf(item) === -1) {
						config.isTourValid = false;
					}
				});

				if (config.isTourValid && config.isTourSP4) {
					var tourList = dirList.filter(function (item) {
						return item.endsWith('.xml');
					});
					if (tourList.length === 1) {
						config.tourFileName = tourList[0].replace(".xml", "");
					} else {
						config.isTourValid = false;
					}
				}
			} else {
				config.isTourValid = false;
			}

			return config;
		},
		getHikesList: function (hikesPath) {
			return fs.readdirSync(hikesPath);
		},
		getToursList: function (toursPath, config) {
			var isXMLFile = config && config.isTourSP4 ? true : false;
			var tourList = fs.readdirSync(toursPath);
			if (isXMLFile) {
				tourList = tourList.filter(function (item) {
					return item.endsWith('.xml');
				});
				tourList = tourList.map(item => item.replace('.xml', ''));
			}
			return tourList;
		},
		getCardsList: function (CardsPath) {
			return fs.readdirSync(CardsPath);
		},
		deleteItem: function (dirPath) {
			fs.removeSync(dirPath);
		},
		copyTourFiles: function (srcDir, DestDir, config) {
			//Validate Xmls
			tourConvertor.convertTours(srcDir, config);

			// Convert unlocalized cards into localized format
			tourI18nConverter.convertTours(srcDir);

			this.copyFiles(path.resolve(srcDir, "cards"), path.resolve(DestDir, "cards"));
			this.copyFiles(path.resolve(srcDir, "hikes"), path.resolve(DestDir, "hikes"));
			if (config.isTourSP4) {
				this.copyFiles(
					path.resolve(srcDir, config.tourFileName + ".xml"),
					path.resolve(DestDir, "tours", config.tourFileName, config.tourFileName + ".xml")
				);
			} else {
				this.copyFiles(path.resolve(srcDir, "tours"), path.resolve(DestDir, "tours"));
			}

		},
		copyFiles: function (srcDir, DestDir) {
			fs.copySync(srcDir, DestDir);
		},
		compareLists: function (oldList, newList) {
			var duplicates = newList.filter(function (item) {
				if (oldList.indexOf(item) !== -1) {
					return true;
				}
				return false;
			});
			return duplicates;
		}
	};
}(ns));

module.exports = ns;
