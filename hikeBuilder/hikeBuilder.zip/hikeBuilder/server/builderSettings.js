var config = require('config')
	, fs = require('fs-extra')
	, path = require('path');

var ns = {};

(function (ns) {
	var VizWorkSpace = config.workspace;
	ns.SETTINGS_FILE_PATH = path.resolve(VizWorkSpace, "hikeBuilderSettings.json");

	ns.TOURS_PATH = "";
	ns.HIKES_PATH = "";
	ns.CARDS_PATH = "";

	ns.settings = null;

	ns.getSettings = function () {
		if (!ns.settings) {
			if (fs.existsSync(ns.SETTINGS_FILE_PATH)) {
				var rawdata = fs.readFileSync(ns.SETTINGS_FILE_PATH);
				try {
					var settings = JSON.parse(rawdata);
					ns.settings = settings;
				} catch (error) {
					console.log(error);
				}
			}
			if (!ns.settings) {
				let settings = {
					"BuilderWorkspace": path.resolve(VizWorkSpace, ".hikeBuilderWS"),
					"dontShowOnLaunch": false
				};
				ns.updateSettings(settings);
			}
		}
		return ns.settings;
	};

	ns.updateSettings = function (settings) {
		try {
			fs.writeFileSync(ns.SETTINGS_FILE_PATH, JSON.stringify(settings, null, 4));
			ns.settings = settings;
		} catch (error) {
			console.log(error);
		}
		ns.UpdatePaths();
		return ns.settings;
	};

	ns.UpdatePaths = function () {
		ns.SOURCE_PATH = path.resolve(ns.settings.BuilderWorkspace, "sourceCode");
		ns.UPLOADS_PATH = path.resolve(ns.settings.BuilderWorkspace, "uploads");
		ns.TOURS_PATH = path.resolve(ns.SOURCE_PATH, "tours");
		ns.HIKES_PATH = path.resolve(ns.SOURCE_PATH, "hikes");
		ns.CARDS_PATH = path.resolve(ns.SOURCE_PATH, "cards");

		if (!fs.existsSync(ns.settings.BuilderWorkspace)) {
			fs.mkdirSync(ns.settings.BuilderWorkspace);
		}
		if (!fs.existsSync(ns.SOURCE_PATH)) {
			fs.mkdirSync(ns.SOURCE_PATH);
		}
		if (!fs.existsSync(ns.UPLOADS_PATH)) {
			fs.mkdirSync(ns.UPLOADS_PATH);
		}
		if (!fs.existsSync(ns.TOURS_PATH)) {
			fs.mkdirSync(ns.TOURS_PATH);
		}
		if (!fs.existsSync(ns.HIKES_PATH)) {
			fs.mkdirSync(ns.HIKES_PATH);
		}
		if (!fs.existsSync(ns.CARDS_PATH)) {
			fs.mkdirSync(ns.CARDS_PATH);
		}
	};

	function ConstantsInIt() {
		ns.getSettings();
		ns.UpdatePaths();
	}
	ConstantsInIt();
}(ns));

module.exports = ns;