var fs = require('fs-extra')
	, path = require('path')
	, zip = require('node-native-zip')
	, hikeUtils = require('../../hikeengine/server/hikeUtils')
	, builderSettings = require('./builderSettings')
	, hikeJSON2XML = require('./hikeJSON2XML')
	, supportedLocales = require('./supportedLocales')
	, _ = require('underscore');

var ns = {};
(function (ns) {

	ns.getAllItems = function (callback) {
		var allItems = {};
		Promise.all([
			ns.getTourItems()
			, ns.getHikeItems()
			, ns.getCardItems()
		])
			.then(function (results) {
				results.map(function (item) {
					Object.keys(item).map(function (itemType) {
						allItems[itemType] = item[itemType];
					});
				});
				callback(allItems);
			}, function (error) {
				callback(allItems);
			});
	};

	ns.getTourItems = function () {
		return new Promise(function (resolve, reject) {
			var tourItems = {};
			fs.readdirSync(builderSettings.TOURS_PATH).forEach(function (tourName) {
				var toursPromise = [];
				if (fs.existsSync(path.resolve(builderSettings.TOURS_PATH, tourName))) {
					toursPromise.push(hikeUtils.getTourById(tourName, builderSettings.TOURS_PATH, null, null, false));
				}
				Promise.all(toursPromise)
					.then(function (results) {
						results.map(function (tour) {
							tourItems[tour.id] = tour;
						});
						resolve({ tours: tourItems });
					}, function (error) {
						resolve({ tours: tourItems });
					});
			});
		});
	};

	ns.getHikeItems = function () {
		return new Promise(function (resolve, reject) {
			var hikeItems = {};
			fs.readdirSync(builderSettings.HIKES_PATH).forEach(function (hikeName) {
				var hikesPromise = [];
				if (fs.existsSync(path.resolve(builderSettings.HIKES_PATH, hikeName))) {
					hikesPromise.push(hikeUtils.getHikeById(hikeName, builderSettings.HIKES_PATH, null, false));
				}

				Promise.all(hikesPromise)
					.then(function (results) {
						results.map(function (hike) {
							hikeItems[hike.id] = hike;
						});
						resolve({ hikes: hikeItems });
					}, function (error) {
						resolve({ hikes: hikeItems });
					});
			});
		});
	};

	ns.getCardItems = function () {
		return new Promise(function (resolve, reject) {
			var cardItems = {};
			fs.readdirSync(builderSettings.CARDS_PATH).forEach(function (cardName) {
				var cardsPromise = [];
				if (fs.existsSync(path.resolve(builderSettings.CARDS_PATH, cardName))) {

					cardsPromise.push(hikeUtils.getCardById(cardName, builderSettings.CARDS_PATH));
				}
				Promise.all(cardsPromise)
					.then(function (results) {
						results.map(function (card) {
							cardItems[card.id] = card;
						});
						resolve({ cards: cardItems });
					}, function (error) {
						resolve({ cards: cardItems });
					});
			});
			resolve({ cards: cardItems });
		});
	};

	function GetItemData(func, params, bloated) {
		bloated = bloated ? bloated : false;
		switch (func) {
			case 'gethike':
				return hikeUtils.getHikeById(params.id, builderSettings.HIKES_PATH, builderSettings.CARDS_PATH, bloated);
			case 'getActualcard':
			case 'getcard':
				return hikeUtils.getCardById(params.id, builderSettings.CARDS_PATH);
			case 'gettour':
				return hikeUtils.getTourById(params.id, builderSettings.TOURS_PATH, builderSettings.HIKES_PATH, builderSettings.CARDS_PATH, bloated);
			case 'getActualhike':
				return new Promise(function (resolve) {
					resolve(
						fs.readFileSync(path.resolve(builderSettings.HIKES_PATH, params.id, params.id + '.xml')).toString()
					);
				});
			case 'getActualtour':
				return new Promise(function (resolve) {
					resolve(
						fs.readFileSync(path.resolve(builderSettings.TOURS_PATH, params.id, params.id + '.xml')).toString()
					);
				});
		}
	}

	ns.getItemData = GetItemData;

	function saveCard(params) {

		var id = params.id;
		var oldId = params.oldId;
		var cardData = params.card;
		if (id !== oldId) {
			fs.removeSync(path.resolve(builderSettings.CARDS_PATH, oldId));
		}
		if (!fs.existsSync(path.resolve(builderSettings.CARDS_PATH, id))) {
			fs.mkdirSync(path.resolve(builderSettings.CARDS_PATH, id));
		}
		fs.writeFileSync(
			path.resolve(builderSettings.CARDS_PATH, id, id + '.json')
			, JSON.stringify(cardData, null, 4));
		return {
			status: 200
		};
	}

	function saveHike(params) {
		var id = params.id;
		var oldId = params.oldId || id;
		var hikeData = params.hike;
		if (oldId && id !== oldId) {
			fs.removeSync(path.resolve(builderSettings.HIKES_PATH, oldId));
		}

		if (!fs.existsSync(path.resolve(builderSettings.HIKES_PATH, id))) {
			fs.mkdirSync(path.resolve(builderSettings.HIKES_PATH, id));
		}
		fs.writeFileSync(
			path.resolve(builderSettings.HIKES_PATH, id, id + '.xml')
			, hikeJSON2XML.convertHikeToXML(hikeData));
		return {
			status: 200
		};
	}

	function saveTour(params) {
		var id = params.id;
		var oldId = params.oldId;
		var tourData = params.tour;
		if (oldId && id !== oldId) {
			fs.removeSync(path.resolve(builderSettings.TOURS_PATH, oldId));
		}
		if (!fs.existsSync(path.resolve(builderSettings.TOURS_PATH, id))) {
			fs.mkdirSync(path.resolve(builderSettings.TOURS_PATH, id));
		}
		fs.writeFileSync(
			path.resolve(builderSettings.TOURS_PATH, id, id + '.xml')
			, hikeJSON2XML.convertTourToXML(tourData));
		return {
			status: 200
		};
	}
	function addFilesToZip(copyData, fileToAcrchive, rootDir) {
		if (!copyData) {
			return;
		}

		var fileObj = null;
		if (copyData.type === 'tour') {
			fileObj = {
				name: rootDir + "/" + copyData.id + ".xml", 	//Name that we want to provide in the zip
				path: path.resolve(builderSettings.TOURS_PATH, copyData.id, copyData.id + ".xml")  //Actual location and file name
			};
		} else if (copyData.type === 'hike') {
			fileObj = {
				name: rootDir + "/hikes/" + copyData.id + "/" + copyData.id + ".xml", 	//Name that we want to provide in the zip
				path: path.resolve(builderSettings.HIKES_PATH, copyData.id, copyData.id + ".xml")  //Actual location and file name
			};
		} else if (copyData.type === 'card') {
			fileObj = {
				name: rootDir + "/cards/" + copyData.id + "/" + copyData.id + ".json", 	//Name that we want to provide in the zip
				path: path.resolve(builderSettings.CARDS_PATH, copyData.id, copyData.id + ".json")  //Actual location and file name
			};
		}

		if (fileObj) {
			if (fs.existsSync(fileObj.path)) {
				fileToAcrchive.push(fileObj);
			}
		}

		if (copyData.consequent) {
			copyData.consequent.map(function (item) {
				addFilesToZip(item, fileToAcrchive, rootDir);
			});
		}

		if (copyData.alternative) {
			copyData.alternative.map(function (item) {
				addFilesToZip(item, fileToAcrchive, rootDir);
			});
		}
	}

	function generateLocalizationData(copyData) {
		const getLocalizationData = (item, localeKey, result) => {
			switch (item.type) {
				case 'tour': // TODO: implement this
				case 'hike': // TODO: implement this
				default:
					break;
				case 'card':
					const localizationData = _.get(item, ['config', 'localization', localeKey]);
					if (!!localizationData) {
						result[`Card.${item.id}`] = localizationData;
					}
					break;
			}

			if (item.consequent) {
				item.consequent.forEach((consequentItem) => {
					getLocalizationData(consequentItem, localeKey, result);
				});
			}

			if (item.alternative) {
				item.alternative.forEach((alternativeItem) => {
					getLocalizationData(alternativeItem, localeKey, result);
				});
			}
		};

		const result = supportedLocales.reduce((accumulator, locale) => {
			const localizationData = {};
			getLocalizationData(copyData, locale.key, localizationData);

			if (_.isEmpty(localizationData)) {
				return accumulator;
			}

			return Object.assign({
				[locale.suffix]: localizationData,
			}, accumulator);
		}, {});

		return result;
	}

	function createZip(params, cb) {
		var type = params.type;
		var ItemPromise = GetItemData('get' + type, params, true);

		ItemPromise
			.then(function (copyData) {
				var fileToAcrchive = [];
				addFilesToZip(copyData, fileToAcrchive, copyData.id);

				const localizationData = generateLocalizationData(copyData);

				var archive = new zip();

				_.each(localizationData, (value, key) => {
					archive.add(`${params.id}/${params.id}${key}.json`, Buffer.from(JSON.stringify(value, null, 2), 'utf8'));
				});

				archive.addFiles(fileToAcrchive, function (err) {
					if (err) {
						return console.log("err while adding files", err);
					}

					var buff = archive.toBuffer();
					cb && cb(buff.toString('base64'));
				});
			});

	}

	ns.updateItemData = function (func, params) {
		switch (func) {
			case 'updateCard':
				return saveCard(params);
			case 'updateHike':
				return saveHike(params);
			case 'updateTour':
				return saveTour(params);
		}
	};

	ns.exportItem = function (func, params, cb) {
		createZip(params, cb);
	};

	ns.deleteItem = function (params) {
		switch (params.type) {
			case 'cards':
				fs.removeSync(path.resolve(builderSettings.CARDS_PATH, params.id));
				break;
			case 'hikes':
				fs.removeSync(path.resolve(builderSettings.HIKES_PATH, params.id));
				break;
			case 'tours':
				fs.removeSync(path.resolve(builderSettings.TOURS_PATH, params.id));
				break;
		}

		return {
			status: 200
		};
	};

}(ns));

module.exports = ns;
