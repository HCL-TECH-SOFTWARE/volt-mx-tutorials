var builder = require('xmlbuilder');

var ns = {};

(function (ns) {
	ns.typeMap = {
		"hike": "Hike",
		"tour": "Guidedtour",
		"card": "Hikecard",
		"if": "If",
		"else": "Else"
	};

	function addDescription(xmlElement, jsonObj) {
		var description = jsonObj.description ? jsonObj.description : jsonObj.meta.description;
		xmlElement.ele('Description', null, description);

		delete jsonObj.meta.description;
	}

	function addRootAttributes(xmlElement, jsonObj) {
		xmlElement.att('kuid', jsonObj.kuid)
			.att('id', jsonObj.id)
			.att('title', jsonObj.title);
	}

	function addMeta(xmlElement, jsonObj) {
		var meta = jsonObj.meta;
		var metaKeys = Object.keys(meta);
		if (metaKeys.length > 0) {
			var xmlMeta = xmlElement.ele('Meta');
			metaKeys.map(function (key) {
				xmlMeta.ele(key, null, meta[key]);
			});
		}
	}

	ns.convertHikeToXML = function (hikeJSON) {
		var xml = builder.create(ns.typeMap["hike"]);

		addRootAttributes(xml, hikeJSON);
		addDescription(xml, hikeJSON);
		addMeta(xml, hikeJSON);

		hikeJSON.consequent.forEach(element => {
			xml.ele(ns.typeMap[element.type])
				.att('id', element.id);
		});
		var hkeXMLString = xml.end({
			pretty: true,
			indent: '    ',
			newline: '\n',
			spacebeforeslash: ''
		});
		return hkeXMLString;
	};

	ns.convertTourToXML = function (tourJSON) {
		var storedConditions = {};
		var returnXMLString = "";
		var tourXML = builder.create(ns.typeMap['tour']);

		addRootAttributes(tourXML, tourJSON);
		addDescription(tourXML, tourJSON);
		addMeta(tourXML, tourJSON);

		if (tourJSON.entryCondition) {
			if (tourJSON.entryCondition.attributes && tourJSON.entryCondition.attributes.conditionId) {
				tourXML.att('conditionType', 'storedcondition')
					.att('launchCondition', tourJSON.entryCondition.attributes.conditionId);
				storedConditions[tourJSON.entryCondition.attributes.conditionId] = {
					attributes: tourJSON.entryCondition.attributes,
					args: tourJSON.entryCondition.args
				};
			}
		}
		tourJSON.consequent.forEach(element => {
			if (ns.typeMap[element.type] === 'HikeCard' || ns.typeMap[element.type] === 'Hike') {
				tourXML.ele(ns.typeMap[element.type])
					.att('id', element.id);
			} else {
				if (element.type === "if") {
					var ifElem = tourXML.ele(ns.typeMap[element.type]);
					if (element.attributes) {
						ifElem.att('conditionType', 'storedcondition')
							.att('launchCondition', element.attributes.conditionId);

						storedConditions[element.attributes.conditionId] = {
							attributes: element.attributes,
							args: element.args
						};
					}
					element.consequent.forEach(function (hikeJSON) {
						ifElem.ele(ns.typeMap[hikeJSON.type])
							.att('id', hikeJSON.id);
					});
					if (element.alternative.length > 0) {
						var elseElem = tourXML.ele(ns.typeMap['else']);
						element.alternative.forEach(function (hikeJSON) {
							elseElem.ele(ns.typeMap[hikeJSON.type])
								.att('id', hikeJSON.id);
						});
					}
				}
			}
		});

		var conditions = Object.keys(storedConditions);

		if (conditions.length > 0) {
			var conditionsXML = tourXML.ele('Storedconditions');
			Object.keys(storedConditions).forEach(function (conditionId) {
				var condition = storedConditions[conditionId];
				var conditionEle = conditionsXML.ele('Storedcondition')
					.att('id', conditionId)
					.att('conditionType', condition.attributes.conditionType)
					.att('launchCondition', condition.attributes.launchCondition);
				condition.args.forEach(function (params) {
					if (params.type && params.type === "context") {
						conditionEle.ele('Context')
							.att('name', params.name)
							.att('value', params.value);
					} else {
						conditionEle.ele('Args')
							.att('name', params.name)
							.att('value', params.value);
					}
				});
			});
		}
		returnXMLString = tourXML.end({
			pretty: true,
			indent: '    ',
			newline: '\n',
			spacebeforeslash: ''
		});
		return returnXMLString;
	};

}(ns));
module.exports = ns;