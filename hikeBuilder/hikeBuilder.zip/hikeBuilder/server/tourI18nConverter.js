const fs = require('fs-extra');
const path = require('path');
const _ = require('underscore');

const convertTours = (inputPath) => {
  if (!fs.existsSync(inputPath)) {
    console.error('Failed to convert hikes into localized format - Invalid input directory');
    return;
  }

  try {
    const cardsPath = path.resolve(inputPath, 'cards');
    const allCards = fs.readdirSync(
      cardsPath,
      { withFileTypes: true },
    ).filter((file) => file.isDirectory());

    allCards.forEach((file) => {
      try {
        const cardName = file.name;
        const cardPath = path.resolve(cardsPath, cardName, `${cardName}.json`);
        const card = require(cardPath);        

        if (!!card.localization) {
          console.log(`${cardName} is already in localized format`);
          return;
        }

        const defaultLocalizationObj = _.pick(card, [
          ['content', 'title'],
          ['content', 'body'],
          ['navigationBar', 'left', 'text'],
          ['navigationBar', 'right', 'text'],
        ]);

        const newCard = {
          ...card,
          localization: {
            'en-us': defaultLocalizationObj,
          },
        };

        fs.writeFileSync(cardPath, JSON.stringify(newCard, null, 2));
        console.log(`Converted ${cardName} into localized format`);
      } catch (error) {
        console.log(error);
      }
    });

  } catch (error) {
    console.error(error);
  }
};

exports.convertTours = convertTours;